<?php

function currentHour() {
   return intval(time() / (60 * 60));
   }

function generateVerification() {
   return sha1($_SERVER["HTTP_HOST"] . currentHour());
   }

function validVerification($verification) {
   return (
      $verification == sha1($_SERVER["HTTP_HOST"] . currentHour()) ||
      $verification == sha1($_SERVER["HTTP_HOST"] . currentHour() - 1));
   }

function currentPage($pages) {
   $request = $_GET["page"];
   foreach ($pages as $page)
      if ($request == $page->{"page"} && $page->{"show"})
         return $page->{"page"};
   return $request == "thanks" ? "thanks" : "gallery";
   }

function menuItemHtml($page, $name, $current) {
   $link = $page == "gallery" ? "." : "?page=" . $page;
   $class = $page == $current ? " class=currentpage" : "";
   return "<li$class><a href='$link'>$name</a>\n";
   }

function displayMenuBar($pages, $current) {
   echo "<div class=menubar><ul>";
   foreach ($pages as $page)
      if ($page->{"show"})
         echo menuItemHtml($page->{"page"}, $page->{"name"}, $current);
   echo "</ul></div>\n";
   }

function displayGallery($italicTitle, $capsTitle) {
   $fieldId =          "id";
   $fieldCaption =     "caption";
   $fieldDescription = "description";
   $captionClass = "b " . ($italicTitle ? "i " : "") . ($capsTitle ? "c" : "");
   $captionStyleStart =  htmlspecialchars("<span class='$captionClass'>", ENT_QUOTES);
   $captionStyleEnd =    htmlspecialchars("</span><br>");
   $galleryDb = readDb("data/gallery-db.json");
   echo "<div class=gallery>\n";
   foreach ($galleryDb as $imageDb) {
      $id =          $imageDb->{$fieldId};
      $caption =     $imageDb->{$fieldCaption};
      $description = $imageDb->{$fieldDescription};
      echo "<div class=image><a href='data/portfolio/$id-large.jpg' rel='lightbox{gallery}'
         title='$captionStyleStart$caption$captionStyleEnd$description'><img
         src='data/portfolio/$id-small.png' alt='Thumbnail'
         title='Click for full size, and right arrow to advance'></a>
         <p class='$captionClass'>$caption</p></div>\n";
      }
   echo "</div>\n";
   }

function contactPageHtml() {
   $verification = generateVerification();
   return "<h3>Contact Artist</h3>
      <script type='text/javascript'>
         document.writeln('<fo' + 'rm method=post act' + 'ion=feed' + 'back.php>');</script>
      <input type=hidden name=verification value=$verification>
      <p><label>Message:</label>
         <textarea name=message rows=6 cols=50></textarea></p>
      <p><label>Name:</label>
         <input name=name size=35></p>
      <p><label>Email:</label>
         <input name=email size=40></p>
      <p><label>&nbsp;</label>
         <input class=click type=submit value=' Send Message '></p>
      <script type='text/javascript'>
         document.writeln('<input type=hidden name=real value=window.location.hostname><\\/form>');</script>
      <p class=corner-msg>Gallery powered by
         <a href='http://www.centerkey.com/ppages/'>PPAGES</a></p>";
   }

function contactThanksHtml() {
   $msg = isset($_GET["invalid"]) ? "Error!" : "Your message has been sent.";
   return "<h3>Thank You</h3><p>$msg</p>
      <p><input type=submit class=click value=' << Back to Gallery '
         onClick='window.location=\".\";'></p>";
   }

function displayPage($name) {
   echo "<div class=page>\n";
   if ($name == "contact")
      echo contactPageHtml();
   else if ($name == "thanks")
      echo contactThanksHtml();
   else {
      echo "$name";
      }
   echo "</div>\n";
   }

function displayCreativeCommons() {
   echo "&nbsp;&nbsp;
      <a rel='license' href='http://creativecommons.org/licenses/by-sa/3.0/'
      target='_blank'><img alt='Creative Commons License'
      title='These works are licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License'
      src='http://i.creativecommons.org/l/by-sa/3.0/80x15.png'></a>\n";
   }

function displayFooter($statement, $license, $bookmarks) {
   echo "<div class=footer><div>\n";
   if ($license)
      displayCreativeCommons();
   if ($bookmarks)
      include "components/bookmarking.html";
   echo "</div>$statement</div>\n";
   }

?>
