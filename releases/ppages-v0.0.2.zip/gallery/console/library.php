<?php
$version="0.2";
include "database.php";

$dataFolder = "../data/";
$customCssFile =   $dataFolder . "style.css";  //for site customizations
$graphicsFolder =  $dataFolder . "graphics/";  //for site customizations
$maskDataFile =    $dataFolder . "index.html";  //block folder browsing
$uploadsFolder =   $dataFolder . "uploads/";
$portfolioFolder = $dataFolder . "portfolio/";
$galleryDbFile =   $dataFolder . dbFileName("gallery");

$origFileCode =  "-original";
$thumbFileCode = "-small";
$thumbFileExt =  ".png";
$fullFileCode =  "-large";
$fullFileExt =   ".jpg";

$thumbHeight =      150;
$fullWidthMax =    1100;
$fullHeightMax =    800;
$imageDbFilter =   $portfolioFolder . dbFileName("*");
$imageOrigFilter = $portfolioFolder . "*" . $origFileCode . "*";

$imageFieldId =           "id";
$imageFieldOrigFileName = "original-file-name";
$imageFieldUploadDate =   "upload-date";
$imageFieldDisplay =      "display";  //boolean: "on"=show, ""=hide
$imageFieldCaption =      "caption";
$imageFieldDescription =  "description";

$actionField =           "action";
$actionUpdateImage =     "update-image";
$actionUpdateSettings =  "update-settings";
$actionUpdateMenuBar =   "update-menu-bar";
$actionReprocessImages = "reprocess-images";
$actionChangePassword =  "change-password";
$actionCreateAccount =   "create-account";
$actionsMenuBar = array(
   "Save name", "Move up", "Move down", "Display", "Hide", "Edit page", "Delete");

$settingsDbFile = $dataFolder . dbFileName("settings");

include "console.php";
include "console-login.php";
include "console-transfer.php";
include "console-accounts.php";
include "console-settings.php";
include "console-portfolio.php";
include "console-process.php";

function getFileExtension($fileName) {
   return strtolower(strrchr($fileName, "."));
   }

function isImageFile($fileName) {
   return stripos("..jpg.jpeg.png.", getFileExtension($fileName) . ".") > 0;
   }

function imageToFile($origImage, $origWidth, $origHeight, $newWidth, $newHeight, $newFile) {
   $newImage = imagecreatetruecolor($newWidth, $newHeight);
   imagecopyresampled($newImage, $origImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);
   getFileExtension($newfile) == ".png" ?
      imagepng($newImage, $newFile) : imagejpeg($newImage, $newFile);
   imagedestroy($newImage);
   }

?>
