<?php

$imageNum = 0;

function getFreeImageId() {
   global $imageDbFilter, $imageNum;
   static $numLen = 3;  //ex: "037"
   if (!$imageNum)  //"gallery/037.json" --> 38
      $imageNum = 1 + trim(end(glob($imageDbFilter)), "a..z/.");
   return str_pad($imageNum, $numLen, "0", STR_PAD_LEFT);  //38 --> "038"
   }

function setNextImageId() {
   global $imageNum;
   $imageNum++;
   }

function generateGalleryDb() {
   global $galleryDbFile, $portfolioFolder, $imageDbFilter;
   global $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate, $imageFieldDisplay, $imageFieldCaption, $imageFieldDescription;
   $galleryDb = array();
   $dbFiles = glob($imageDbFilter);
   foreach ($dbFiles as $dbFile) {
      $imageDb = readDb($dbFile);
      if ($imageDb->{$imageFieldDisplay} == "on")
         $galleryDb[] = $imageDb;
      }
   saveDb($galleryDbFile, $galleryDb);
   }

function processUpdateImageDb() {
   global $portfolioFolder, $imageDbFilter;
   global $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate, $imageFieldDisplay, $imageFieldCaption, $imageFieldDescription;
   $imageId = $_POST[$imageFieldId];
   echo "<div>Updating record: #$imageId</div>";
   $dbFile = $portfolioFolder . dbFileName($imageId);
   $imageDb = readDb($dbFile);
   $imageDb->{$imageFieldDisplay} =     $_POST[$imageFieldDisplay];
   $imageDb->{$imageFieldCaption} =     $_POST[$imageFieldCaption];
   $imageDb->{$imageFieldDescription} = $_POST[$imageFieldDescription];
   saveDb($dbFile, $imageDb);
   generateGalleryDb();
   }

function displayPortfolioHtml($id, $status, $title, $desc, $date, $thumbFile, $file, $origFile, $origFileName) {
   global $imageFieldId, $imageFieldDisplay, $imageFieldCaption, $imageFieldDescription;
   global $actionField, $actionUpdateImage;
   $checked = $status ? " checked" : "";
   echo "<a name=$id><div class=image-box><a href='$origFile'
      target='_blank'><img src='$thumbFile' alt='$file'
      title='Click to view original uploaded file ($origFileName)'></a>
      <form method=post action='#$id'>
         <input type='hidden' name='$actionField' value='$actionUpdateImage'>
         <input type='hidden' name='$imageFieldId' value='$id'>
         <label>Display:</label><input type=checkbox class=click name='$imageFieldDisplay'$checked> <small>(show in gallery)</small><br>
         <label>Caption:</label><input type=text name='$imageFieldCaption' size=30 value='$title'><br>
         <label>Description:</label><textarea name='$imageFieldDescription' rows=4 cols=25>$desc</textarea><br>
         <label>Uploaded:</label><small>$date</small><br>
         <label>&nbsp;</label><input type=submit class='click' value=' Update Image Information '>
         </form>
      <br class=all></div>\n";
   }

function displayPortfolio() {
   global $portfolioFolder, $origFileCode, $thumbFileCode, $thumbFileExt, $imageDbFilter;
   global $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate, $imageFieldDisplay, $imageFieldCaption, $imageFieldDescription;
   $dbFiles = glob($imageDbFilter);
   foreach ($dbFiles as $dbFile) {
      $imageDb = ReadDb($dbFile);
      $imageId = $imageDb->{$imageFieldId};
      $base = $portfolioFolder . $imageDb->{$imageFieldId};
      $thumbFile = $base . $thumbFileCode . $thumbFileExt;
      $origFileName = $imageDb->{$imageFieldOrigFileName};
      $origFile = $base . $origFileCode . getFileExtension($origFileName);
      displayPortfolioHtml($imageId, $imageDb->{$imageFieldDisplay} == "on",
         $imageDb->{$imageFieldCaption}, $imageDb->{$imageFieldDescription},
         $imageDb->{$imageFieldUploadDate},
         $thumbFile, $file, $origFile, $origFileName);
      }
   if (count($dbFiles) == 0)
      echo "<p>There are no photos in your portfolio.</p>";
   }

?>
