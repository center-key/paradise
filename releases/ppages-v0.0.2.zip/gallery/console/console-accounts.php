<?php

$accountsDbFilter = $dataFolder . dbFileName("accounts-*");
$accountsDbFile =   null;  //set at run-time
$accountsDb =       null;

$accountFieldUsername = "username";  //used in html forms, but not db
$accountFieldHash =     "hash";
$accountFieldType =     "type";  //"regular"(TBD) or "administrator"

$salt = ltrim($_SERVER["HTTP_HOST"], "w.");  //transmit: sha1(password + salt)

function accountsJavaScript() {
   global $salt;
   echo "<script src=sha1hash.js type='text/javascript'></script>
   <script type='text/javascript'>
   function validateAccountRules(uname, pass, pass2) {
      var valid = false;
      if (uname.length == 0)
         alert('Username cannot be blank.');
      else if (pass != pass2)
         alert('Passwords do not match.');
      else if (pass.length < 8)
         alert('Password must be at least 8 characters long.');
      else
         valid = true;
      return valid;
      }
   function login(validate) {
      var uname =  document.getElementById('username').value;
      var pass =   document.getElementById('password').value;
      var hash = sha1Hash(pass + '$salt');
      document.getElementById('submit-username').value = uname;
      document.getElementById('submit-hash').value = hash;
      if (!validate || validateAccountRules(uname, pass,
            document.getElementById('password2').value))
         document.getElementById('submit-login').submit();
      }
   function changePassword() {
      var pass =   document.getElementById('password').value;
      var pass2 =  document.getElementById('password2').value;
      var hash = sha1Hash(pass + '$salt');
      document.getElementById('submit-hash').value = hash;
      if (validateAccountRules('ignore', pass, pass2))
         document.getElementById('submit-change-password').submit();
      }
   function confirmResetPassword(uname) {
      return confirm('You are about to reset the password for \"' + uname + '\".\\n\\nContinue?');
      }
   function cleanupUsername(uname) {
      return uname.toLowerCase().replace(/[^a-z0-9-]/g,'');
      }
   function randomPassword() {
      return sha1Hash(new Date()).replace(/[01]/g,'').substring(0,8);
      }
   function confirmAccountAction(uname) {
      alert('This feaure is not ready yet.');
      return false;
      }
   function confirmCreateAccount(uname) {
      var pass = randomPassword();
      var hash = sha1Hash(pass + '$salt');
      var msg = 'You are about to create the following user account.\\n\\tUsername: ' + uname + '\\n\\tPassword: ' + pass + '\\n(Hint: You can select and copy the above password.)\\n\\nContinue?';
      document.getElementById('submit-new-username').value = uname;
      document.getElementById('submit-new-hash').value = hash;
      if (uname.length == 0)
         alert('Username cannot be blank.');
      else if (confirm(msg))
         document.getElementById('submit-create-account').submit();
      }
   </script>\n";
   }

function getAccountsDb() {
   global $accountsDbFilter, $accountsDbFile, $accountsDb;
   if ($accountsDb == null) {
      $dbFileSearch = glob($accountsDbFilter);
      if (count($dbFileSearch) == 0) {
         $accountsDbFile = str_replace("*" , mt_rand(0, 999999999999),
            $accountsDbFilter);
         saveDb($accountsDbFile, createEmptyDb());
         }
      else
         $accountsDbFile = $dbFileSearch[0];
      $accountsDb = readDb($accountsDbFile);
      }
   return $accountsDb;
   }

function saveAccountsDb($newAccountsDb) {
   global $accountsDbFile, $accountsDb;
   saveDb($accountsDbFile, $newAccountsDb);
   $accountsDb = readDb($accountsDbFile);
   }

function getNumAccounts() {
   return count((array)getAccountsDb());
   }

function cleanupUsername($username) {
   return "" . preg_replace("/[^a-z0-9-]/", "", strtolower($username));
   }

function lookupAccount($username) {
   return getAccountsDb()->{cleanupUsername($username)};
   }

/*
function addAccount($username, $hash, $type) {
   global $accountsDbFile, $accountsDb;
   global $accountFieldHash, $accountFieldType;
   if (!lookupAccount($username)) {
      $accountsDb->{cleanupUsername($username)} = array (
         $accountFieldHash => sha1($hash),
         $accountFieldType => $type,
         );
      saveDb($accountsDbFile, $accountsDb);
      $accountsDb = readDb($accountsDbFile);
      }
   }
*/

function displayChangePassword() {
   global $actionField, $actionChangePassword, $accountFieldHash;
   echo "<form action='javascript:changePassword();'>
      <fieldset><legend>Your Password</legend>
         <p><label>New Password:</label><input type='password' id='password' size='20'></p>
         <p><label>Verify Password:</label><input type='password' id='password2' size='20'></p>
         <p><label>&nbsp;</label><input type='submit' class='click' value=' Change Password '></p>
         </fieldset>
      </form>
      <form action='.' method='post' id='submit-change-password'>
         <input type='hidden' name='$actionField' value='$actionChangePassword'>
         <input type='hidden' name='$accountFieldHash'   id='submit-hash'>
         </form>\n";
   }

function updateAccount($username, $hash, $type, $msg) {
   global $accountFieldHash, $accountFieldType;
   $accountsDb = getAccountsDb();
   if ($hash)
      $accountsDb->{$username}->{$accountFieldHash} = sha1($hash);
   if ($type)
      $accountsDb->{$username}->{$accountFieldType} = $type;
   saveAccountsDb($accountsDb);
   echo $msg;
   }

function processChangePassword() {
   global $accountFieldUsername, $accountFieldHash;
   $username = $_SESSION[$accountFieldUsername];
   $hash = $_POST[$accountFieldHash];
   $msg = "<div>Your password has been updated.</div>";
   if (lookupAccount($username))
      updateAccount($username, $hash, null, $msg);
   else
      echo "<div class=warning>Account not found: $username</div>";
   }

function processCreateAccount() {
   global $accountFieldUsername, $accountFieldHash;
   $username = cleanupUsername($_POST[$accountFieldUsername]);
   $hash = $_POST[$accountFieldHash];
   $msg = "<div>New user account created: $username</div>";
   if (lookupAccount($username))
      echo "<div class=warning>The user account '$username' already exists.</div>";
   else
      updateAccount($username, $hash, "administrator", $msg);
   }

function displayAccountsListHtml($username) {
   global $actionField, $actionAccountAdmin, $accountFieldUsername;
   $disabled = $username == $_SESSION[$accountFieldUsername];
   $adminOptions = "<option>Reset Password</option><option>Delete Account</option>";
   echo "<form method=post onsubmit='return confirmAccountAction(\"$username\");'>
      <input type='hidden' name='$actionField' value='$actionAccountAdmin'>
      <p>" . ($disabled ? "<i>" : "") . "$username" . ($disabled ? "</i>" : "") . "
      <select name='' id='account-account'" . ($disabled ? " disabled" : "") .
      ">$adminOptions</select><input type=submit class=click
      value='Go'" . ($disabled ? " disabled" : "") . "></p>
      </form>\n";
   }

function displayAccountsList() {
   echo "<fieldset><legend>All Accounts</legend>\n";
   foreach (getAccountsDb() as $username => $account)
      displayAccountsListHtml($username);
   echo "</fieldset>\n";
   }

function displayCreateAccount() {
   global $accountFieldUsername, $accountFieldHash, $actionField, $actionCreateAccount;
   echo "<form action='javascript:confirmCreateAccount(document.getElementById(\"username\").value);'>
      <fieldset><legend>New Account</legend>
         <p><label>Username:</label><input type=text id=$accountFieldUsername
            size=20 onblur='this.value=cleanupUsername(this.value);'></p>
         <p><label>&nbsp;</label><input type=submit class=click
            value=' Create New User Account '></p>
         </fieldset>
      </form>
      <form action='.' method=post id=submit-create-account>
         <input type=hidden name=$actionField          value=$actionCreateAccount>
         <input type=hidden name=$accountFieldUsername id=submit-new-username>
         <input type=hidden name=$accountFieldHash     id=submit-new-hash>
         </form>\n";
   }

function displayAccounts() {
   displayChangePassword();
   displayAccountsList();
   displayCreateAccount();
   }

function accountValidHash($username, $hash) {
   global $accountFieldHash;
   if (getNumAccounts() == 0)
      processCreateAccount();
   $_SESSION["username"] = cleanupUsername($username);
   $account = lookupAccount($username);
   return sha1($hash) == $account->{$accountFieldHash};
   }

?>
