<?php

$settingsFieldTitle =         "title";
$settingsFieldTitleFont =     "title-font";
$settingsFieldTitleSize =     "title-size";
$settingsFieldSubtitle =      "subtitle";
$settingsFieldFooter =        "footer";
$settingsFieldCaptionItalic = "caption-italic";  //boolean
$settingsFieldCaptionCaps =   "caption-caps";  //boolean
$settingsFieldCcLicense =     "cc-license";  //boolean
$settingsFieldBookmarks =     "bookmarks";  //boolean
$settingsFieldEmail =         "email";
$settingsFieldPages =         "pages";  //array

$settingsFields = array(
   $settingsFieldTitle,
   $settingsFieldTitleFont,
   $settingsFieldTitleSize,
   $settingsFieldSubtitle,
   $settingsFieldFooter,
   $settingsFieldCaptionItalic,
   $settingsFieldCaptionCaps,
   $settingsFieldCcLicense,
   $settingsFieldBookmarks,
   $settingsFieldEmail,
   $settingsFieldPages);
$settingsFieldsHtml = array(
   $settingsFieldTitle,
   $settingsFieldSubtitle,
   $settingsFieldFooter);

function settingsJavaScript() {
   echo "<script type='text/javascript'>
      function confirmMenuBarAction(action, title) {
         alert('Sorry, this feature is not ready yet.');
         return action != 'Delete' ||
            confirm('You are about to delete the \"' + title + '\" page.  Continue?');
         }
      </script>\n";
   }

function bbcodeToHtml($bbcode) {
   //Turn text with bbcode into displayable HTML (supports: b, i, url, and entities)
   $code = array('/\[b\](.*?)\[\/b\]/is', '/\[i\](.*?)\[\/i\]/is', '/\[url\=(.*?)\](.*?)\[\/url\]/is', '/\[\&amp\;(.*?)\;\]/is');
   $html = array('<b>$1</b>',             '<i>$1</i>',             '<a href="$1">$2</a>',              '&$1;');
   return preg_replace($code, $html, $bbcode);
   }

function getGoogleFonts() {  //http://code.google.com/webfonts
   return array ("Allan", "Allerta", "Allerta Stencil", "Anonymous Pro", "Arimo",
      "Arvo", "Bentham", "Buda", "Cabin", "Cantarell", "Cardo", "Coda", "Copse",
      "Corben", "Cousine", "Covered By Your Grace", "Crimson Text", "Cuprum",
      "Droid Sans", "Droid Sans Mono", "Droid Serif", "Geo", "Gruppo", "IM Fell",
      "Inconsolata", "Josefin Sans", "Josefin Slab", "Just Another Hand",
      "Just Me Again Down Here", "Kenia", "Kristi", "Lato", "Lekton", "Lobster",
      "Merriweather", "Molengo", "Mountains of Christmas", "Neucha", "Neuton",
      "Nobile", "OFL Sorts Mill Goudy TT", "Old Standard TT", "Orbitron",
      "PT Sans", "Philosopher", "Puritan", "Raleway", "Reenie Beanie", "Sniglet",
      "Syncopate", "Tangerine", "Tinos", "Ubuntu", "UnifrakturCook",
      "UnifrakturMaguntia", "Vibur", "Vollkorn", "Yanone Kaffeesatz");
   }

function booleanStr($enabled) {
   return $enabled ? "on" : "";
   }

function getDefaultSettings() {
   global $settingsFieldTitle, $settingsFieldTitleFont, $settingsFieldTitleSize,
      $settingsFieldSubtitle, $settingsFieldFooter,
      $settingsFieldCaptionItalic, $settingsFieldCaptionCaps,
      $settingsFieldCcLicense, $settingsFieldBookmarks, $settingsFieldPages;
   $page1->{"page"} = "gallery";  $page1->{"name"} = "Gallery";  $page1->{"show"} = true;
   $page2->{"page"} = "artist";   $page2->{"name"} = "Artist";   $page2->{"show"} = false;
   $page3->{"page"} = "contact";  $page3->{"name"} = "Contact";  $page3->{"show"} = true;
   return array(
      $settingsFieldTitle =>         "My Gallery",
      $settingsFieldTitleFont =>     "Reenie Beanie",
      $settingsFieldTitleSize =>     "400%",
      $settingsFieldSubtitle =>      "Photography [&amp;bull;] Art Studio",
      $settingsFieldFooter =>        "Copyright [&amp;copy;] " . gmdate("Y"),
      $settingsFieldCaptionItalic => booleanStr(true),
      $settingsFieldCaptionCaps =>   booleanStr(false),
      $settingsFieldCcLicense =>     booleanStr(false),
      $settingsFieldBookmarks =>     booleanStr(true),
      $settingsFieldPages =>         array($page1, $page2, $page3));
   }

function readSettings($settingsDbFile) {
   global $settingsFieldsHtml;
   $settingsDb = readDb($settingsDbFile);
   foreach (getDefaultSettings() as $fieldName => $default)
      if ($settingsDb->{$fieldName} === null)
         $settingsDb->{$fieldName} = $default;
   foreach ($settingsFieldsHtml as $fieldName)
      if ($settingsDb->{$fieldName . "-html"} === null)
         $settingsDb->{$fieldName . "-html"} = bbcodeToHtml($settingsDb->{$fieldName});
   return $settingsDb;
   }

function fontOptions($defaultFont) {
   global $settingsFieldTitleFont;
   $options = "<select name='$settingsFieldTitleFont'>";
   foreach (getGoogleFonts() as $fontName)
      $options .= "<option" . ($fontName == $defaultFont ? " selected" : "") .
         ">$fontName</option>\n";
   $options .= "</select>";
   return $options;
   }

function sizeOptions($defaultSize) {
   global $settingsFieldTitleSize;
   $options = "<select name='$settingsFieldTitleSize'>";
   for ($size = 1; $size < 10; $size++)
      $options .= "<option" . ($size == substr($defaultSize, 0, 1) ?
         " selected" : "") . ">$size" . "00%</option>\n";
   $options .= "</select>";
   return $options;
   }

function checkedHtml($fieldValue) {
   return $fieldValue == "on" ? " checked" : "";
   }

function displaySettingsWebsite($settingsDb) {
   global $actionUpdateSettings;
   global $settingsFieldTitle, $settingsFieldTitleFont, $settingsFieldTitleSize,
      $settingsFieldSubtitle, $settingsFieldFooter,
      $settingsFieldCaptionItalic, $settingsFieldCaptionCaps,
      $settingsFieldCcLicense, $settingsFieldBookmarks,
      $settingsFieldEmail;
   $emailHelp = "Information filled out by users in the contact form is sent to this e-mail address";
   $title =     $settingsDb->{$settingsFieldTitle};
   $fonts =     fontOptions($settingsDb->{$settingsFieldTitleFont});
   $sizes =     sizeOptions($settingsDb->{$settingsFieldTitleSize});
   $subtitle =  $settingsDb->{$settingsFieldSubtitle};
   $footer =    $settingsDb->{$settingsFieldFooter};
   $italic =    checkedHtml($settingsDb->{$settingsFieldCaptionItalic});
   $caps =      checkedHtml($settingsDb->{$settingsFieldCaptionCaps});
   $cc =        checkedHtml($settingsDb->{$settingsFieldCcLicense});
   $bookmarks = checkedHtml($settingsDb->{$settingsFieldBookmarks});
   $email =     $settingsDb->{$settingsFieldEmail};
   echo "<form method=post action='.'>\n";
   echo "<input type=hidden name=action value='$actionUpdateSettings'>\n";
   echo "<fieldset><legend>Website</legend>
      <p><label>Title:</label><input type=text name=$settingsFieldTitle
         size=30 value='$title'></p>
      <p><label>Title Font:<a href='http://code.google.com/webfonts'
         target=_blank><img src=icon-info.png alt='Information Icon'
         title='Click to see fonts'></a></label>$fonts</p>
      <p><label>Title Size:</label>$sizes</p>
      <p><label>Subtitle:</label><input type=text
         name=$settingsFieldSubtitle size=30 value='$subtitle'></p>
      <p><label>Footer:</label><input type=text name=$settingsFieldFooter
         size=30 value='$footer'></p>
      <p><label>Image Titles:</label>
         <input type=checkbox name=$settingsFieldCaptionItalic$italic><i>italic</i> &nbsp;
         <input type=checkbox name=$settingsFieldCaptionCaps$caps><small>ALL CAPS</small>
         </p>
      <p><label>Creative Commons Icon:<a
         href='http://creativecommons.org/licenses/by-sa/3.0/'
         target=_blank><img src=icon-info.png alt='Information Icon'
         title='Click for information'></a></label>
         <input type=checkbox name=$settingsFieldCcLicense$cc>display</p>
      <p><label>Social Bookmark Icons:</label>
         <input type=checkbox name=$settingsFieldBookmarks$bookmarks>display</p>
      <p><label>E-mail:<img src=icon-info.png title='$emailHelp'
         alt='Information Icon'></label><input type=text
         name=$settingsFieldEmail size=30 value='$email'></p>
      <p><input class=click type=submit value=' Update Gallery Settings '></p>
      </fieldset>\n";
   echo "</form>\n";
   }

function disabledMenuAction($action, $name, $loc, $len, $show) {
   return
      ($action == "Move up" &&   $loc < 2) ||
      ($action == "Move down" && ($loc == $len - 1 || $name == "gallery")) ||
      ($action == "Display" &&   $show) ||
      ($action == "Hide" &&      (!$show || $name == "gallery")) ||
      ($action == "Edit page" && ($name == "gallery" || $name == "contact")) ||
      ($action == "Delete" &&    ($name == "gallery" || $name == "contact"));
   }

function displaySettingsMenuBar($pages) {
   global $actionUpdateMenuBar, $actionsMenuBar;
   echo "<fieldset><legend>Menu Bar</legend>\n";
   foreach ($pages as $loc => $p) {
      $name = $p->{"name"};
      $page = $p->{"page"};
      $show = $p->{"show"};
      $options = "<select name=zzz>";
      foreach ($actionsMenuBar as $action)
         $options .= "<option" . (disabledMenuAction($action, $page,
            $loc, count($menuOptions), $show) ? " disabled" : "") .
            ">$action</option>\n";
      $options .= "</select>";
      $hidden = $show ? "" : "<small><i>hidden</i></small>";
      echo "<p><form method=post action='.'
         onsubmit='return confirmMenuBarAction(this.zzz.value, \"$name\");'>
         <input type=hidden name=action value=$actionUpdateMenuBar>
         <input type=hidden name=menu-bar-name value=$page>
         $hidden
         <input type=text name=x size=10 value='$name'>$options<input
            type=submit class=click value='Go'></p>
         </form></p>\n";
      }
   echo "</fieldset>\n";
   }

function displaySettingsReprocess() {
   global $actionReprocessImages;
   $confirmMsg = '"You are about to regenerate all the thumbnail images and slideshow images.  Continue?"';
   echo "<form method=post action='.'; onsubmit='return confirm($confirmMsg);'>\n";
   echo "<input type=hidden name=action value='$actionReprocessImages'>\n";
   echo "<fieldset><legend>Image Processing</legend>
      <p><input class=click type=submit value=' Reprocess Images '></p>
      </fieldset>\n";
   echo "</form>\n";
   }

function displaySettings() {
   global $settingsDbFile, $settingsFieldPages;
   $settingsDb = readSettings($settingsDbFile);
   displaySettingsWebsite($settingsDb);
   displaySettingsMenuBar($settingsDb->{$settingsFieldPages});
   //displaySettingsReprocess();  //prereq: add dimentions to settings
   }

function processUpdateSettings() {
   global $settingsDbFile, $settingsFields, $settingsFieldsHtml, $settingsFieldPages;
   $settingsDb = createEmptyDb();
   foreach ($settingsFields as $fieldName)
       $settingsDb->{$fieldName} = "" . $_POST[$fieldName];
   foreach ($settingsFieldsHtml as $fieldName)
       $settingsDb->{$fieldName . "-html"} = bbcodeToHtml($settingsDb->{$fieldName});
   $settingsDb->{$settingsFieldPages} = readSettings($settingsDbFile)->{$settingsFieldPages};
   saveDb($settingsDbFile, $settingsDb);
   echo "<div>Updated gallery settings.</div>";
   }

function processUpdateMenuBar() {
   echo "<div>Sorry, processUpdateMenuBar is not ready yet.</div>";
   }

?>
