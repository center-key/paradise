<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<!--  PHP Portfolio Art Gallery Exhibit Showcase (PPAGES)                      -->
<!--  http://www.centerkey.com/ppages                                          -->
<!--                                                                           -->
<!--  GNU General Public License:                                              -->
<!--  This program is free software; you can redistribute it and/or modify it  -->
<!--  under the terms of the GNU General Public License as published by the    -->
<!--  Free Software Foundation; either version 2 of the License, or (at your   -->
<!--  option) any later version.                                               -->
<!--                                                                           -->
<!--  This program is distributed in the hope that it will be useful, but      -->
<!--  WITHOUT ANY WARRANTY; without even the implied warranty of               -->
<!--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                     -->
<!--                                                                           -->
<!--  See the GNU General Public License at http://www.gnu.org for more        -->
<!--  details.                                                                 -->
<!--                                                                           -->
<!--  Copyright (c) individual contributors to the PPAGES project              -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<html>
<head>
<title>PPAGES  &bull;  Gallery Management Console</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="icon"       type="image/png" href="../favicon.png">
<link rel="stylesheet" type="text/css"  href="style.css">
<link rel="stylesheet" type="text/css"  href="fileuploader.css">
<?php
   include "library.php";
   function successfullLogin() {
      return $_POST["action"] == "login" &&
         accountValidHash($_POST["username"], $_POST["hash"]);
      }
   if (isset($_GET["logout"]))
      session_unset();
   if (isset($_SESSION["active"]) && time() - $_SESSION["active"] > 60*20)
      session_unset();
   if (isset($_SESSION["active"]) || successfullLogin())
      $_SESSION["active"] = time();
   $loggedIn = isset($_SESSION["active"]);
   settingsJavaScript();
   accountsJavaScript();
?>
</head>
<body>

<div class=header>
   <div>
      <input type=submit class=click onClick="window.open('..');" value=" Visit Gallery "><br>
      <?php if ($loggedIn) { ?>
      <input type=submit class=click onClick="window.location='?logout';" value=" Logout "><br>
      <?php } ?>
      </div>
   <h1>PHP Portfolio Art Gallery Exhibit Showcase (PPAGES)</h1>
   <h2>Gallery Management Console</h2>
</div>

<?php $loggedIn ? displayConsole() : displayLogin(); ?>

<br class=all>
<div class=footer>
   <?php if ($loggedIn)
      echo "You are logged into " . $_SERVER['HTTP_HOST'] . " as " .
         $_SESSION["username"] . "<br>\n";
      ?>
   PHP Portfolio Art Gallery Exhibit Showcase (PPAGES)<br>
   </div>
</body>
</html>
