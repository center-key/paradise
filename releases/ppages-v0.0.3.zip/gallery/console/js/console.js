// PPAGES ~ www.centerkey.com/ppages ~ Copyright (c) individual contributors
// Rights granted under GNU General Public License ~ ppages/src/gallery/license.txt

function confirmMenuBarAction(form, title) {
   var action = $('select[name=menu-bar-action]', form).val();
   return action != 'del' ||
      confirm('You are about to delete the "' + title + '" page.  Continue?');
   }
