<?php
// PPAGES ~ www.centerkey.com/ppages ~ Copyright (c) individual contributors
// Rights granted under GNU General Public License ~ ppages/src/gallery/license.txt

$imageNum = 0;

function getFreeImageId() {
   global $imageDbFilter, $imageNum;
   static $numLen = 3;  //ex: "037"
   if (!$imageNum)  //"gallery/037.json" --> 38
      $imageNum = 1 + trim(end(glob($imageDbFilter)), "a..z/.");
   return str_pad($imageNum, $numLen, "0", STR_PAD_LEFT);  //38 --> "038"
   }

function setNextImageId() {
   global $imageNum;
   $imageNum++;
   }

function generateGalleryDb() {
   global $galleryDbFile, $portfolioFolder, $imageDbFilter,
      $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate,
      $imageFieldDisplay, $imageFieldCaption, $imageFieldDescription, $imageFieldBadge;
   $galleryDb = array();
   $dbFiles = glob($imageDbFilter);
   foreach ($dbFiles as $dbFile) {
      $imageDb = readDb($dbFile);
      if ($imageDb->{$imageFieldDisplay} == "on")
         $galleryDb[] = $imageDb;
      }
   saveDb($galleryDbFile, $galleryDb);
   }

function processUpdateImageDb() {
   global $portfolioFolder, $imageDbFilter,
      $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate,
      $imageFieldDisplay, $imageFieldCaption, $imageFieldDescription, $imageFieldBadge;
   $imageId = $_POST[$imageFieldId];
   echo "<div>Updating record: #$imageId</div>";
   $dbFile = $portfolioFolder . dbFileName($imageId);
   $imageDb = readDb($dbFile);
   $imageDb->{$imageFieldDisplay} =     $_POST[$imageFieldDisplay];
   $imageDb->{$imageFieldCaption} =     $_POST[$imageFieldCaption];
   $imageDb->{$imageFieldDescription} = $_POST[$imageFieldDescription];
   $imageDb->{$imageFieldBadge} =       $_POST[$imageFieldBadge];
   saveDb($dbFile, $imageDb);
   generateGalleryDb();
   }

function processDeleteImageDb() {
   echo "<div class=warning>Sorry, the delete image feature is not ready yet.</div>";
   }

function displayPortfolioHtml($id, $status, $title, $desc, $badge, $date, $thumbFile, $file, $origFile, $origFileName) {
   global $imageFieldId, $imageFieldDisplay, $imageFieldCaption,
      $imageFieldDescription, $imageFieldBadge,
      $actionField, $actionUpdateImage, $actionDeleteImage;
   $checked = $status ? " checked" : "";
   echo "<a name=$id><div class=image-box><a class=external-link
      href='$origFile'><img src='$thumbFile' alt='$file'
      title='Click to view original uploaded file ($origFileName)'></a>
      <form method=post action=#$id>
         <input type=hidden name=$actionField value=$actionUpdateImage>
         <input type=hidden name=$imageFieldId value=$id>
         <label>Display:</label><input type=checkbox name=$imageFieldDisplay$checked> <small>(show in gallery)</small><br>
         <label>Caption:</label><input type=text name=$imageFieldCaption size=30 value='$title'><br>
         <label>Description:</label><textarea name=$imageFieldDescription rows=4 cols=25>$desc</textarea><br>
         <label>Badge:</label><input type=text name=$imageFieldBadge size=15 value='$badge'><br>
         <label>Uploaded:</label><small>$date</small><br>
         <label>&nbsp;</label><button>Update Image Information</button>
         </form>
      <form method=post action='#$id'>
         <input type=hidden name=$actionField value=$actionDeleteImage>
         <input type=hidden name=$imageFieldId value=$id>
         <label>&nbsp;</label><button>Delete Image</button>
         </form>
      <br class=all></div>\n";
   }

function displayPortfolio() {
   global $portfolioFolder, $origFileCode, $thumbFileCode, $thumbFileExt,
      $imageDbFilter, $imageFieldId, $imageFieldOrigFileName,
      $imageFieldUploadDate, $imageFieldDisplay, $imageFieldCaption,
      $imageFieldDescription, $imageFieldBadge;
   $dbFiles = glob($imageDbFilter);
   foreach ($dbFiles as $dbFile) {
      $imageDb = ReadDb($dbFile);
      $imageId = $imageDb->{$imageFieldId};
      $base = $portfolioFolder . $imageDb->{$imageFieldId};
      $thumbFile = $base . $thumbFileCode . $thumbFileExt;
      $origFileName = $imageDb->{$imageFieldOrigFileName};
      $origFile = $base . $origFileCode . getFileExtension($origFileName);
      displayPortfolioHtml($imageId, $imageDb->{$imageFieldDisplay} == "on",
         $imageDb->{$imageFieldCaption}, $imageDb->{$imageFieldDescription},
         $imageDb->{$imageFieldBadge}, $imageDb->{$imageFieldUploadDate},
         $thumbFile, $file, $origFile, $origFileName);
      }
   if (count($dbFiles) == 0)
      echo "<p>There are no photos in your portfolio.</p>";
   }

?>
