<?php
// PPAGES ~ www.centerkey.com/ppages ~ Copyright (c) individual contributors
// Rights granted under GNU General Public License ~ ppages/src/gallery/license.txt

$version="0.3";
include "database.php";

$dataFolder = "../data/";
$customCssFile =   $dataFolder . "style.css";  //for site customizations
$graphicsFolder =  $dataFolder . "graphics/";  //for site customizations
$maskDataFile =    $dataFolder . "index.html";  //block folder browsing
$uploadsFolder =   $dataFolder . "uploads/";
$portfolioFolder = $dataFolder . "portfolio/";
$galleryDbFile =   $dataFolder . dbFileName("gallery");

$origFileCode =  "-original";
$thumbFileCode = "-small";
$thumbFileExt =  ".png";
$fullFileCode =  "-large";
$fullFileExt =   ".jpg";

$thumbHeight =      150;
$fullWidthMax =    1100;
$fullHeightMax =    800;
$imageDbFilter =   $portfolioFolder . dbFileName("*");
$imageOrigFilter = $portfolioFolder . "*" . $origFileCode . "*";

$imageFieldId =           "id";
$imageFieldOrigFileName = "original-file-name";
$imageFieldUploadDate =   "upload-date";
$imageFieldDisplay =      "display";  //boolean: "on"=show, ""=hide
$imageFieldCaption =      "caption";
$imageFieldDescription =  "description";
$imageFieldBadge =        "badge";

$actionField =           "action";
$actionUpdateImage =     "update-image";
$actionDeleteImage =     "delete-image";
$actionUpdateSettings =  "update-settings";
$actionUpdateMenuBar =   "update-menu-bar";
$actionReprocessImages = "reprocess-images";
$actionChangePassword =  "change-password";
$actionCreateAccount =   "create-account";
$actionsMenuBar = array("save"=>"Save name", "up"=>"Move up", "down"=>"Move down",
   "show"=>"Show", "hide"=>"Hide", "edit"=>"Edit page", "del"=>"Delete");

$settingsDbFile = $dataFolder . dbFileName("settings");

include "console.php";
include "console-login.php";
include "console-transfer.php";
include "console-accounts.php";
include "console-settings.php";
include "console-portfolio.php";
include "console-process.php";

function getFileExtension($fileName) {
   return strtolower(strrchr($fileName, "."));
   }

function isImageFile($fileName) {
   return stripos("..jpg.jpeg.png.", getFileExtension($fileName) . ".") > 0;
   }

function imageToFile($origImage, $origWidth, $origHeight, $newWidth, $newHeight, $newFile) {
   $newImage = imagecreatetruecolor($newWidth, $newHeight);
   imagecopyresampled($newImage, $origImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);
   getFileExtension($newfile) == ".png" ?
      imagepng($newImage, $newFile) : imagejpeg($newImage, $newFile);
   imagedestroy($newImage);
   }

?>
