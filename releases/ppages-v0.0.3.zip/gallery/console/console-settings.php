<?php
// PPAGES ~ www.centerkey.com/ppages ~ Copyright (c) individual contributors
// Rights granted under GNU General Public License ~ ppages/src/gallery/license.txt

$settingsFieldTitle =         "title";
$settingsFieldTitleFont =     "title-font";
$settingsFieldTitleSize =     "title-size";
$settingsFieldSubtitle =      "subtitle";
$settingsFieldFooter =        "footer";
$settingsFieldCaptionItalic = "caption-italic";  //boolean
$settingsFieldCaptionCaps =   "caption-caps";  //boolean
$settingsFieldCcLicense =     "cc-license";  //boolean
$settingsFieldBookmarks =     "bookmarks";  //boolean
$settingsFieldEmail =         "email";
$settingsFieldPages =         "pages";  //array

$settingsFields = array(
   $settingsFieldTitle,
   $settingsFieldTitleFont,
   $settingsFieldTitleSize,
   $settingsFieldSubtitle,
   $settingsFieldFooter,
   $settingsFieldCaptionItalic,
   $settingsFieldCaptionCaps,
   $settingsFieldCcLicense,
   $settingsFieldBookmarks,
   $settingsFieldEmail,
   $settingsFieldPages);
$settingsFieldsHtml = array(
   $settingsFieldTitle,
   $settingsFieldSubtitle,
   $settingsFieldFooter);

function bbcodeToHtml($bbcode) {
   //Turn text with bbcode into displayable HTML (supports: b, i, url, and entities)
   $code = array('/\[b\](.*?)\[\/b\]/is', '/\[i\](.*?)\[\/i\]/is', '/\[url\=(.*?)\](.*?)\[\/url\]/is', '/\[\&amp\;(.*?)\;\]/is');
   $html = array('<b>$1</b>',             '<i>$1</i>',             '<a href="$1">$2</a>',              '&$1;');
   return preg_replace($code, $html, $bbcode);
   }

function getGoogleFonts() {  //http://code.google.com/webfonts
   return array ("Allan", "Allerta", "Allerta Stencil", "Anonymous Pro", "Arimo",
      "Arvo", "Bentham", "Bowlby One SC", "Buda", "Cabin", "Cantarell", "Cardo",
      "Cherry Cream Soda", "Chewy", "Coda", "Copse",
      "Corben", "Cousine", "Covered By Your Grace", "Crimson Text", "Cuprum",
      "Droid Sans", "Droid Sans Mono", "Droid Serif", "Geo", "Gruppo",
      "Homemade Apple", "IM Fell",
      "Inconsolata", "Josefin Sans", "Josefin Slab", "Just Another Hand",
      "Just Me Again Down Here", "Kenia", "Kristi", "Lato", "Lekton", "Lobster",
      "Merriweather", "Molengo", "Neucha", "Neuton",
      "Nobile", "OFL Sorts Mill Goudy TT", "Old Standard TT", "Orbitron",
      "PT Sans", "Philosopher", "Puritan", "Raleway", "Reenie Beanie",
      "Rock Salt", "Slackey", "Sniglet", "Special Elite",
      "Syncopate", "Tangerine", "Tinos", "Ubuntu", "UnifrakturCook",
      "UnifrakturMaguntia", "Vibur", "Vollkorn", "Yanone Kaffeesatz");
   }

function booleanStr($enabled) {
   return $enabled ? "on" : "";
   }

function getDefaultSettings() {
   global $settingsFieldTitle, $settingsFieldTitleFont, $settingsFieldTitleSize,
      $settingsFieldSubtitle, $settingsFieldFooter,
      $settingsFieldCaptionItalic, $settingsFieldCaptionCaps,
      $settingsFieldCcLicense, $settingsFieldBookmarks, $settingsFieldPages;
   $page1->name = "gallery";  $page1->title = "Gallery";  $page1->show = true;
   $page2->name = "artist";   $page2->title = "Artist";   $page2->show = false;
   $page3->name = "contact";  $page3->title = "Contact";  $page3->show = true;
   return array(
      $settingsFieldTitle =>         "My Gallery",
      $settingsFieldTitleFont =>     "Reenie Beanie",
      $settingsFieldTitleSize =>     "400%",
      $settingsFieldSubtitle =>      "Photography [&amp;bull;] Art Studio",
      $settingsFieldFooter =>        "Copyright [&amp;copy;] " . gmdate("Y"),
      $settingsFieldCaptionItalic => booleanStr(true),
      $settingsFieldCaptionCaps =>   booleanStr(false),
      $settingsFieldCcLicense =>     booleanStr(false),
      $settingsFieldBookmarks =>     booleanStr(true),
      $settingsFieldPages =>         array($page1, $page2, $page3));
   }

function readSettings($settingsDbFile) {
   global $settingsFieldsHtml;
   $settingsDb = readDb($settingsDbFile);
   foreach (getDefaultSettings() as $fieldName => $default)
      if ($settingsDb->{$fieldName} === null)
         $settingsDb->{$fieldName} = $default;
   foreach ($settingsFieldsHtml as $fieldName)
      if ($settingsDb->{$fieldName . "-html"} === null)
         $settingsDb->{$fieldName . "-html"} = bbcodeToHtml($settingsDb->{$fieldName});
   return $settingsDb;
   }

function fontOptions($defaultFont) {
   global $settingsFieldTitleFont;
   $options = "<select name=$settingsFieldTitleFont>";
   foreach (getGoogleFonts() as $fontName)
      $options .= "<option" . ($fontName == $defaultFont ? " selected" : "") .
         ">$fontName</option>\n";
   $options .= "</select>";
   return $options;
   }

function sizeOptions($defaultSize) {
   global $settingsFieldTitleSize;
   $options = "<select name=$settingsFieldTitleSize>";
   for ($size = 1; $size < 10; $size++)
      $options .= "<option" . ($size == substr($defaultSize, 0, 1) ?
         " selected" : "") . ">$size" . "00%</option>\n";
   $options .= "</select>";
   return $options;
   }

function checkedHtml($fieldValue) {
   return $fieldValue == "on" ? " checked" : "";
   }

function displaySettingsWebsite($settingsDb) {
   global $actionUpdateSettings;
   global $settingsFieldTitle, $settingsFieldTitleFont, $settingsFieldTitleSize,
      $settingsFieldSubtitle, $settingsFieldFooter,
      $settingsFieldCaptionItalic, $settingsFieldCaptionCaps,
      $settingsFieldCcLicense, $settingsFieldBookmarks,
      $settingsFieldEmail;
   $emailHelp = "Information filled out by users in the contact form is sent to this e-mail address";
   $title =     $settingsDb->{$settingsFieldTitle};
   $fonts =     fontOptions($settingsDb->{$settingsFieldTitleFont});
   $sizes =     sizeOptions($settingsDb->{$settingsFieldTitleSize});
   $subtitle =  $settingsDb->{$settingsFieldSubtitle};
   $footer =    $settingsDb->{$settingsFieldFooter};
   $italic =    checkedHtml($settingsDb->{$settingsFieldCaptionItalic});
   $caps =      checkedHtml($settingsDb->{$settingsFieldCaptionCaps});
   $cc =        checkedHtml($settingsDb->{$settingsFieldCcLicense});
   $bookmarks = checkedHtml($settingsDb->{$settingsFieldBookmarks});
   $email =     $settingsDb->{$settingsFieldEmail};
   echo "<form method=post action='.'>\n";
   echo "<input type=hidden name=action value=$actionUpdateSettings>\n";
   echo "<fieldset><legend>Website</legend>
      <p><label>Title:</label><input type=text name=$settingsFieldTitle
         size=30 value='$title'></p>
      <p><label>Title Font:<a class=external-link
         href='http://code.google.com/webfonts'><img src=icon-info.png
         alt='Information Icon' title='Click to see fonts'></a></label>$fonts</p>
      <p><label>Title Size:</label>$sizes</p>
      <p><label>Subtitle:</label><input type=text
         name=$settingsFieldSubtitle size=30 value='$subtitle'></p>
      <p><label>Footer:</label><input type=text name=$settingsFieldFooter
         size=30 value='$footer'></p>
      <p><label>Image Titles:</label>
         <input type=checkbox name=$settingsFieldCaptionItalic$italic><i>italic</i> &nbsp;
         <input type=checkbox name=$settingsFieldCaptionCaps$caps><small>ALL CAPS</small>
         </p>
      <p><label>Creative Commons Icon:<a class=external-link
         href='http://creativecommons.org/licenses/by-sa/3.0/'><img
         src='icon-info.png'alt='Information Icon'
         title='Click for information'></a></label>
         <input type=checkbox name=$settingsFieldCcLicense$cc>display</p>
      <p><label>Social Bookmark Icons:</label>
         <input type=checkbox name=$settingsFieldBookmarks$bookmarks>display</p>
      <p><label>E-mail:<img src=icon-info.png title='$emailHelp'
         alt='Information Icon'></label><input type=text
         name=$settingsFieldEmail size=30 value='$email'></p>
      <p><button>Update Gallery Settings</button></p>
      </fieldset>\n";
   echo "</form>\n";
   }

function menuBarActionAllowed($action, $name, $loc, $len, $show) {
   return
      ($action == "save") ||
      ($action == "up"   && ($loc > 1)) ||
      ($action == "down" && ($loc != $len - 1 && $name != "gallery")) ||
      ($action == "show" && (!$show)) ||
      ($action == "hide" && ($show && $name != "gallery")) ||
      ($action == "edit" && ($name != "gallery" && $name != "contact")) ||
      ($action == "del"  && ($name != "gallery" && $name != "contact"));
   }

function displaySettingsMenuBar($pages) {
   global $actionUpdateMenuBar, $actionsMenuBar;
   echo "<fieldset><legend>Menu Bar</legend>\n";
   foreach ($pages as $loc => $page) {
      if (!isset($page->title)) {  //TODO: Delete this backwards compatibility workaround
         $page->title = $page->name;
         $page->name = strtolower($page->name);
         }
      $options = "<select name=menu-bar-action>";
      foreach ($actionsMenuBar as $action => $actionName)
         $options .= "<option value=" . $action . (menuBarActionAllowed($action,
            $page->name, $loc, count($menuOptions), $page->show) ? "" : " disabled") .
            ">$actionName</option>\n";
      $options .= "</select>";
      $hidden = $page->show ? "" : "<small><i>hidden</i></small>";
      echo "<p><form method=post action='.'
         onsubmit='return confirmMenuBarAction(this, \"{$page->title}\");'>
         <input type=hidden name=action value=$actionUpdateMenuBar>
         <input type=hidden name=menu-bar-name value={$page->name}>
         $hidden
         <input type=text name=menu-bar-title size=10
         value='{$page->title}'>$options<button>Go</button></p>
         </form></p>\n";
      }
   echo "</fieldset>\n";
   }

function displaySettingsReprocess() {
   global $actionReprocessImages;
   $confirmMsg = '"You are about to regenerate all the thumbnail images and slideshow images.  Continue?"';
   echo "<form method=post action='.'; onsubmit='return confirm($confirmMsg);'>\n";
   echo "<input type=hidden name=action value=$actionReprocessImages>\n";
   echo "<fieldset><legend>Image Processing</legend>
      <p><button>Reprocess Images</button></p>
      </fieldset>\n";
   echo "</form>\n";
   }

function displaySettings() {
   global $settingsDbFile, $settingsFieldPages;
   $settingsDb = readSettings($settingsDbFile);
   displaySettingsWebsite($settingsDb);
   displaySettingsMenuBar($settingsDb->{$settingsFieldPages});
   //displaySettingsReprocess();  //prereq: add dimentions to settings
   }

function processUpdateSettings() {
   global $settingsDbFile, $settingsFields, $settingsFieldsHtml, $settingsFieldPages;
   $settingsDb = createEmptyDb();
   foreach ($settingsFields as $fieldName)
       $settingsDb->{$fieldName} = "" . $_POST[$fieldName];
   foreach ($settingsFieldsHtml as $fieldName)
       $settingsDb->{$fieldName . "-html"} = bbcodeToHtml($settingsDb->{$fieldName});
   $settingsDb->{$settingsFieldPages} = readSettings($settingsDbFile)->{$settingsFieldPages};
   if (saveDb($settingsDbFile, $settingsDb))
      echo "<div>Updated gallery settings.</div>";
   else
      echo "<div class=warning>Error saving gallery settings.</div>";
   }

function processUpdateMenuBar() {
   global $settingsDbFile, $settingsFieldPages;
   $pageSelected = $_POST["menu-bar-name"];
   $pageAction = $_POST["menu-bar-action"];
   $pageTitle = $_POST["menu-bar-title"];
   $settingsDb = readSettings($settingsDbFile);
   $pages = $settingsDb->{$settingsFieldPages};
   foreach ($pages as $page) {     //TODO: Delete this backwards compatibility workaround
      if (!isset($page->title))
         $page->title = $page->name;
      $page->name = strtolower($page->name);
      unset($page->page);
      }
   $msg = null;
   foreach ($pages as $slot => $page)
      if ($page->name == $pageSelected)
         switch ($pageAction) {
            case "save":
               strlen($pageTitle) > 0 ? $page->title = $pageTitle :
                  $msg = "Page title cannot be blank"; break;
            case "up": $msg = "Sorry, $pageAction is not ready yet."; break;
            case "down": $msg = "Sorry, $pageAction is not ready yet."; break;
            case "show": $page->show = true; break;
            case "hide": $page->show = false; break;
            case "edit": $msg = "Temporary fix is to edit 'data/page-$pageSelected.html' file."; break;
            case "del": $msg = "Sorry, $pageAction is not ready yet."; break;
            }
   if ($msg)
      echo "<div class=warning>Error updating menu bar settings: $msg</div>";
   else if (saveDb($settingsDbFile, $settingsDb))
      echo "<div>Updated menu bar settings.</div>";
   else
      echo "<div class=warning>Error saving menu bar settings to DB.</div>";
   }

?>
