//! paradise v0.6.0 ~~ https://github.com/center-key/paradise ~~ GPL-3.0 License
const gallery={start(){$("body >footer .hide-me").remove();$("form.send-message").attr({method:"post",action:"frontend-server/send-message.php"});const options={delegate:">a",type:"image",image:{titleSrc:"data-title"},gallery:{enabled:true}};$(".gallery-images figure").magnificPopup(options)}};$(gallery.start);
