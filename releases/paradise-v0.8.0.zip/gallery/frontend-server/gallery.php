<?php
///////////////////////////////////////////////////////////////
// Paradise ~ centerkey.com/paradise                         //
// GPLv3 ~ Copyright (c) Individual contributors to Paradise //
///////////////////////////////////////////////////////////////

// Gallery
//
// $settings (settings-db.json):
//    { title: "My Gallery", titleFont: "Geo", titleSize: "800%", subtitle: "Art Studio", darkMode: true, ... }
// $gallery (gallery-db.json):
//    [{ id: "001", code: "tree-house", caption: "Tree House!", description: "Cool.", ... }, ...]

require __DIR__ . "/../common.php";

function getData($dbFilename) {
   // Returns an object or array of objects corresponding to the contents of the DB.
   if (!is_file($dbFilename))
      exit("Setup incomplete");  //displayed to all users until initial admin account is created
   return json_decode(file_get_contents($dbFilename));
   }

function showHideClass($show) {
   // Returns a class name to be applied to a DOM element
   return $show ? "show-me" : "hide-me";
   }

function linkText($url) {
   // Returns the clean displayable version of the link.
   // Example: "https://example.com/gallery/" --> "example.com/gallery"
   $parts = explode("//", $url);
   return rtrim(end($parts), "/");
   }

function styleClasses($settings) {
   // Example:
   //    { title: "My Gallery!", darkMode: true, imageBorder: false, show-Description: true }
   //    --> "dark-mode show-description"
   $options = [
      "dark-mode",
      "image-border",
      "show-description",
      "caption-caps",
      "caption-italic",
      ];
   $enabled = function($property) use ($settings) { return $settings->{toCamelCase($property)}; };
   return implode(" ", array_filter($options, $enabled));
   }

function getImagesHtml($gallery, $settings) {
   // Returns a string of "<figure>...</figure>" tags representing the content of the gallery.
   // TODO: $image ==> $imageInfo or $imageDb ????
   $stampIcon =    $settings->stampIcon;
   $titleAttr =    "title='" . str_replace("'", "&apos;", $settings->stampTitle ?? "") . "'";
   $stampTooltip = empty($settings->stampTitle) ? "" : $titleAttr;
   function toImageHtml($image, $stampIcon, $stampTooltip) {
      $badgeHtml =      empty($image->badge) ? "" : "<span class=badge>{$image->badge}</span>";
      $hasStamp =       isset($image->stamp) && $image->stamp && !empty($stampIcon);
      $stampHtml =      $hasStamp ? "<i class=stamp data-icon={$stampIcon} {$stampTooltip}></i>" : "";
      $captionHtml =    "<span class=image-caption>{$image->caption}</span>";
      $descHtml =       "<span class=image-description>{$image->description}</span>";
      $imageTitleHtml = str_replace("'", "&apos;", $captionHtml . $descHtml);
      $image->code =    toUriCode($image->caption);  //backwards compatibility (temporary)
      return "
         <figure itemprop=associatedMedia itemscope itemtype=https://schema.org/ImageObject>
            <a href=~data~/portfolio/{$image->id}-large.jpg data-title='{$imageTitleHtml}' itemprop=contentUrl>
               <img src=~data~/portfolio/{$image->id}-small.png alt=thumbnail itemprop=thumbnail>
               <aside>
                  {$stampHtml}
                  {$badgeHtml}
               </aside>
            </a>
            <figcaption>
               <a href=image/{$image->id}/{$image->code} class=plain itemprop=url><i data-icon=link></i></a>
               <span itemprop=caption>{$image->caption}</span>
               <p itemprop=description>{$image->description}</p>
            </figcaption>
         </figure>";
      };
   $imagesHtml = implode(PHP_EOL, array_map(
      function ($image) use ($stampIcon, $stampTooltip) {
         return toImageHtml($image, $stampIcon, $stampTooltip);
         },
      $gallery));
   return empty($gallery) ? "<h2>Gallery is empty</h2>" : $imagesHtml;
   }

function getImageInfo($uri, $gallery) {
   $id =            preg_match("/\/image\/([0-9]+)/", $uri, $matches) ? $matches[1] : "missing";
   $dbFilename =    __DIR__ . "/../~data~/portfolio/{$id}-db.json";
   $missingImage =  '{ "caption": "That image does not appear to exist", "description": "" }';
   $content =       is_file($dbFilename) ? file_get_contents($dbFilename) : $missingImage;
   $imageDb =       json_decode($content);
   $imageDb->code = toUriCode($imageDb->caption);  //backwards compatibility (temporary)
   $galleryUrl =    getGalleryUrl();
   $meta = (object)[
      "id" =>          $id,
      "code" =>        $imageDb->code,
      "caption" =>     $imageDb->caption,
      "description" => $imageDb->description,
      "canonical" =>   "{$galleryUrl}/image/{$id}/{$imageDb->code}",
      "urlSmall" =>    "{$galleryUrl}/~data~/portfolio/{$id}-small.png",
      "urlLarge" =>    "{$galleryUrl}/~data~/portfolio/{$id}-large.jpg",
      ];
   return $meta;
   }

function setValues($settings, $gallery) {
   $titleFontParam = urlencode($settings->titleFont);
   $artistPageFile = __DIR__ . "/../~data~/page-{$settings->pages[1]->name}.html";
   $galleryUrl =     getGalleryUrl();
   $id =             empty($gallery) ? "NA" : $gallery[0]->id;
   return (object)[
      "cardImageUrl" =>   "{$galleryUrl}/~data~/portfolio/{$id}-large.jpg",
      "thumbnailUrl" =>   "{$galleryUrl}/~data~/portfolio/{$id}-small.png",
      "titleFontUrl" =>   "https://fonts.googleapis.com/css?family={$titleFontParam}",
      "styleClasses" =>   styleClasses($settings),
      "artistPageHtml" => $settings->pages[1]->show ? file_get_contents($artistPageFile) : "",
      ];
   }

$settings = getData(__DIR__ . "/../~data~/settings-db.json");
$gallery =  getData(__DIR__ . "/../~data~/gallery-db.json");
$values =   setValues(migrateSettings($settings), $gallery);
?>
