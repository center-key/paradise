<?php
///////////////////////////////////////////////////////////////
// Paradise ~ centerkey.com/paradise                         //
// GPLv3 ~ Copyright (c) Individual contributors to Paradise //
///////////////////////////////////////////////////////////////

// Administrator Console
// Business logic

function getOutstandingInvites() {
   if (readOnlyMode())
      return $resource = (object)[["to" => "lee@example.com", "date" => date("Y-m-d")]];
   return array_values(array_filter(array_values((array)readAccountsDb()->invites), "outstanding"));
   }

function getBackupFiles() {
   global $backupsFolder;
   $maxNumBackups = 3;
   $files = glob($backupsFolder . "/*.zip");
   function getTimestamp($filename) {  //"travel-2018-09-05-0758.zip" --> "2018-09-05-0758"
      return substr($filename, -19, 15);
      }
   function newest($filenameA, $filenameB) {
      return strcmp(getTimestamp($filenameB), getTimestamp($filenameA));
      }
   usort($files, "newest");
   if (count($files) > $maxNumBackups)
      unlink(array_pop($files));
   function toObjBackup($file) {
      $folder =   basename(dirname($file));
      $filename = basename($file);
      $bytes =    filesize($file);
      return (object)[
         "filename" => basename($file),
         "url" =>      "../~data~/{$folder}/$filename}",
         "bytes" =>    $bytes,
         "size" =>     toMb($bytes),
         ];
      };
   if (readOnlyMode())
      $files = [];
   return array_map("toObjBackup", $files);
   }

function appClientData() {
   // Returns JSON to be inserted into a variable assignment within <script> tag on a web page.
   global $appVersion, $googleFonts;
   $settings = readSettingsDb();
   $data = (object)[
      "appVersion" =>    $appVersion,
      "phpVersion" =>    PHP_VERSION,
      "user" =>          getCurrentUser(),
      "server" =>        $_SERVER["SERVER_NAME"],
      "userListEmpty" => emptyObj(readAccountsDb()->users),
      "title" =>         $settings->title,
      "titleSize" =>     $settings->titleSize,
      "fonts" =>         $googleFonts,
      "invites" =>       getCurrentUser() ? getOutstandingInvites() : [],
      "backupFiles" =>   getCurrentUser() ? getBackupFiles() : [],
      ];
   return json_encode($data);
   }

?>
