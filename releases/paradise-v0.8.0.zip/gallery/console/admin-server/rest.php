<?php
///////////////////////////////////////////////////////////////
// Paradise ~ centerkey.com/paradise                         //
// GPLv3 ~ Copyright (c) Individual contributors to Paradise //
///////////////////////////////////////////////////////////////

// REST API
// JSON-only zone

function restError($code) {
   // Simulate HTTP 400 status code:
   //    http://localhost/paradise-deploy/gallery/console/rest/?resource=bogus
   $errorTable = (object)[
      400 => "Bad request",
      401 => "Unauthorized access",
      402 => "Missing in action",
      404 => "Resource not found",
      500 => "Unknown error",
      501 => "Not implemented",
      ];
   return (object)[
      "error" =>   true,
      "code" =>    $code,
      "message" => $errorTable->$code,
      ];
   }

function runRoute($routes, $action) {
   logEvent(__FILE__, __FUNCTION__, $action);
   $fn = $routes->$action ?? null;
   return $fn ? $fn() : restError(402);
   }

function test() {
   // URL: http://localhost/paradise-deploy/gallery/console/rest?resource=command&action=test
   return (object)[
      "test" => true,
      "data" => (object)[
         "method" =>    $httpMethod = $_SERVER["REQUEST_METHOD"],
         "timestamp" => date("c"),
         "read-only" => readOnlyMode(),
         ],
      ];
   }

function runCommand($action) {
   if ($action == "test")
      $resource = test();
   elseif ($action === "process-uploads")
      $resource = processUploads();
   elseif ($action === "generate-gallery")
      $resource = generateGalleryDb();
   else
      $resource = restError(400);  //invalid parameters
   logEvent(__FILE__, __FUNCTION__, $action);
   return $resource;
   }

function fieldValue($rawValue, $type) {
   $find =  ["<",    ">",    '"',      "'"];
   $use =   ["&lt;", "&gt;", "&quot;", "&apos;"];
   $value = str_replace($find, $use, trim($rawValue));
   if ($type === "boolean")
      $value = $value === "true";
   elseif ($type === "code")
      $value = preg_replace("/[^a-z0-9-]/", "", strtolower($value));
   elseif ($type === "integer")
      $value = intval($value);
   return $value;
   }

function updateItem($resource, $itemType) {
   if ($itemType === "page") {
      $item = $resource->pages[fieldValue(getIdParam(), "integer") - 1];
      if (isset($_GET["title"]))
         $item->title = fieldValue($_GET["title"], "string");
      if (isset($_GET["show"]))
         $item->show = fieldValue($_GET["show"], "boolean");
      }
   }

function updateSettings() {
   $fields = (object)[
      "title" =>              "string",
      "titleFont" =>          "string",
      "titleSize" =>          "string",
      "subtitle" =>           "string",
      "darkMode" =>           "boolean",
      "imageBorder" =>        "boolean",
      "showDescription" =>    "boolean",
      "captionCaps" =>        "boolean",
      "captionItalic" =>      "boolean",
      "stampIcon" =>          "code",
      "stampTitle" =>         "string",
      "ccLicense" =>          "boolean",
      "bookmarks" =>          "boolean",
      "linkUrl" =>            "string",
      "footer" =>             "string",
      "googleVerification" => "string",
      "contactEmail" =>       "string",
      ];
   $resource = readSettingsDb();
   if (isset($_GET["item"]))
      updateItem($resource, $_GET["item"]);
   else
      foreach ($fields as $field => $type)
         if (isset($_GET[$field]))
            $resource->$field = fieldValue($_GET[$field], $type);
   return saveSettingsDb($resource);
   }

function updatePortfolio($id) {
   $fields = (object)[
      "sort" =>        "integer",
      "display" =>     "boolean",
      "caption" =>     "string",
      "description" => "string",
      "badge" =>       "string",
      "stamp" =>       "boolean",
      ];
   $resource = readPortfolioImageDb($id);
   if ($resource) {
      foreach ($fields as $field => $type)
         if (isset($_GET[$field]))
            $resource->$field = fieldValue($_GET[$field], $type);
      if (isset($_GET["move"]))
         $resource->sort = calcNewPortfolioSort($resource->sort, $_GET["move"] === "up");
      $resource->code = toUriCode($resource->caption);
      savePortfolioImageDb($resource);
      generateGalleryDb();
      }
   return $resource ?: restError(404);
   }

function deletePortfolio($id) {
   $resource = readPortfolioImageDb($id);
   if (!readOnlyMode() && $resource) {
      deleteImages($id);
      generateGalleryDb();
      }
   return $resource ?: restError(404);
   }

function restPostLog($data) {
   // Example $data object:
   //    { message: "I'm afraid I can't do that, Dave." }
   if (readOnlyMode())
      $resource = restError(401);
   elseif (isset($data->message)) {
      logEvent(__FILE__, __FUNCTION__, "client-msg", $data->message, strlen($data->message));
      $resource = (object)[
         "message" =>   $data->message,
         "timestamp" => date("c"),
         ];
      }
   else
      $resource = restError(400);  //missing message field
   return $resource;
   }

function restRequestSettings($action) {
   return $action === "update" ? updateSettings() : readSettingsDb();
   }

function restRequestGallery() {
   return readGalleryDb();
   }

function restRequestPortfolio($action, $id) {
   $routes = (object)[
      "create" => function($id) { return restError(400); },
      "get" =>    function($id) { return restError(501); },
      "update" => function($id) { return updatePortfolio($id); },
      "delete" => function($id) { return deletePortfolio($id); },
      "list" =>   function($id) { return readPortfolioDb(); },
      ];
   $fn = $routes->$action;
   return $fn($id);
   }

function restRequestAccount($action, $email) {
   $accountsDb = readAccountsDb();
   $users =      $accountsDb->users;
   $emails =     array_keys((array)$users);
   sort($emails);
   return array_map(function ($email) use ($users) {
      return (object)[
         "email" => $email,
         "login" => $users->$email->login,
         "valid" => $users->$email->valid,
         ];
      }, $emails);
   }

function restRequestBackup($action) {
   function actionCreate() {
      global $backupsFolder;
      function getInvitee($invite) {
         return $invite->to . ($invite->accepted ? " [accepted]" : "");
         }
      $start =    getTime();
      $settings = readSettingsDb();
      $accounts = readAccountsDb();
      $admins =   implode(PHP_EOL, array_keys(get_object_vars($accounts->users)));
      $invitees = implode(PHP_EOL, array_map("getInvitee", get_object_vars($accounts->invites)));
      $userList = date("c") . "\n\nAdministrators:\n" . $admins . "\n\nInvitations:\n" . $invitees;
      $filename = fileSysFriendly($settings->title, 10) . "-" . date("Y-m-d-Hi") . ".zip";
      $path =     $backupsFolder . "/" . $filename;
      $url =      "../~data~/" . basename($backupsFolder) . "/" . $filename;
      $count =    0;
      $bytes =    0;
      $zip =      new ZipArchive();
      logEvent(__FILE__, __FUNCTION__, "start", $filename);
      if (readOnlyMode()) {
         $url =   ".";
         $count = 10;
         sleep(2);
         }
      elseif ($zip->open($path, ZipArchive::CREATE) === true) {
         $options = ["remove_path" => "../../~data~/"];  //https://www.php.net/manual/en/ziparchive.addglob.php
         $zip->addGlob("../../~data~/*.{css,json,html}",     GLOB_BRACE, $options);
         $zip->addGlob("../../~data~/portfolio/*.json",      GLOB_BRACE, $options);
         $zip->addGlob("../../~data~/portfolio/*-small.png", GLOB_BRACE, $options);
         $zip->addGlob("../../~data~/portfolio/*-large.jpg", GLOB_BRACE, $options);
         $zip->deleteName("index.html");
         $zip->addFromString("users.txt", $userList);
         $count = $zip->numFiles;
         $zip->close();
         $bytes = filesize($path);
         }
      $megabytes = toMb($bytes);
      $summary =   "files: " . $count;
      $msecs =     getTime() - $start;
      logEvent(__FILE__, __FUNCTION__, "done", $filename, $megabytes, $summary, "{$msecs} ms");
      return (object)[
         "filename" =>     $filename,
         "url" =>          $url,
         "files" =>        $count,
         "bytes" =>        $bytes,
         "size" =>         $megabytes,
         "milliseconds" => $msecs,
         ];
      }
   $routes = (object)[
      "create" => function() { return actionCreate(); },
      "list" =>   function() { return getBackupFiles(); },
      ];
   return runRoute($routes, $action);
   }

function getIdParam() {
   return strtolower(trim($_GET["id"] ?? ""));
   }

function getEmailParam() {
   return strtolower(trim($_GET["email"] ?? ""));
   }

function resource($loggedIn) {
   $postRoutes = (object)[
      "log" => function($resource) { return restPostLog($resource); },
      ];
   $routes = (object)[
      "settings" =>  function($action) { return restRequestSettings($action); },
      "gallery" =>   function($action) { return restRequestGallery(); },
      "portfolio" => function($action) { return restRequestPortfolio($action, getIdParam()); },
      "account" =>   function($action) { return restRequestAccount($action, getEmailParam()); },
      "invite" =>    function($action) { return restRequestInvite($action, getEmailParam()); },
      "backup" =>    function($action) { return restRequestBackup($action); },
      ];
   $httpMethod =     $_SERVER["REQUEST_METHOD"];
   $name =           $_GET["resource"] ?? null;
   $action =         $_GET["action"] ?? "get";
   $postFn =         $postRoutes->$name ?? null;
   $fn =             $routes->$name ?? null;
   $standardAction = in_array($action, ["create", "get", "update", "delete", "list"]);
   if ($httpMethod === "POST")
      $httpBody = json_decode(file_get_contents("php://input"));
   $hasBody = isset($httpBody);
   if ($name === "security" && $hasBody)
      $resource = restRequestSecurity($action, $httpBody);
   elseif (!$loggedIn)
      $resource = restError(401);
   elseif ($hasBody && $postFn)
      $resource = $postFn($httpBody);
   elseif ($name === "command")
      $resource = runCommand($action);
   elseif ($fn && $standardAction)
      $resource = $fn($action);
   else
      $resource = restError(400);
   logEvent(__FILE__, __FUNCTION__, $httpMethod, $name, $action);
   return $resource;
   }

?>
