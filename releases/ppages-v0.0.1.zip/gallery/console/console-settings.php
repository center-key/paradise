<?php

$settingsFieldTitle =     "title";
$settingsFieldTitleFont = "title-font";
$settingsFieldSubtitle =  "subtitle";
$settingsFieldFooter =    "footer";
$settingsFieldEmail =     "email";

function getGoogleFonts() {  //http://code.google.com/webfonts
   return array (
   "Cantarell",
   "Cardo",
   "Crimson Text",
   "Cuprum",
   "Droid Sans",
   "Droid Sans Mono",
   "Droid Serif",
   "IM Fell",
   "Inconsolata",
   "Josefin Sans Std Light",
   "Lobster",
   "Molengo",
   "Neucha",
   "Neuton",
   "Nobile",
   "OFL Sorts Mill Goudy TT",
   "Old Standard TT",
   "PT Sans",
   "Philosopher",
   "Reenie Beanie",
   "Tangerine",
   "Vollkorn",
   "Yanone Kaffeesatz");
   }

function getDefaultSettings() {
   global $settingsFieldTitle, $settingsFieldTitleFont, $settingsFieldSubtitle, $settingsFieldFooter;
   return array(
      $settingsFieldTitle =>     "My Gallery",
      $settingsFieldTitleFont => "Reenie Beanie",
      $settingsFieldSubtitle =>  "Photography [&amp;bull;] Art Studio",
      $settingsFieldFooter =>    "Copyright [&amp;copy;] " . date("Y"),
      );
   }

function readSettings($settingsDbFile) {
   $settingsDb = readDb($settingsDbFile);
   foreach (getDefaultSettings() as $fieldName => $default)
      if (empty($settingsDb->{$fieldName}))
         $settingsDb->{$fieldName} = $default;
   return $settingsDb;
   }

function fontOptions($defaultFont) {
   global $settingsFieldTitleFont;
   $options = "<select name='$settingsFieldTitleFont'>";
   foreach (getGoogleFonts() as $fontName)
      $options .= "<option" . ($fontName == $defaultFont ? " selected" : "") . ">$fontName</option>\n";
   $options .= "</select><a href='http://code.google.com/webfonts'
      target='_blank'><img src='icon-info.png' alt='Information Icon' title='Click to see fonts'></a></small>";
   return $options;
   }

function displaySettings() {
   global $settingsDbFile;
   global $settingsFieldTitle, $settingsFieldTitleFont, $settingsFieldSubtitle, $settingsFieldFooter, $settingsFieldEmail;
   global $actionUpdateSettings;
   $emailHelp = "Information filled out by users in the contact form is sent to this e-mail address";
   $settingsDb = readSettings($settingsDbFile);
   echo "<fieldset>
      <legend>Website</legend>
      <form method=post action='.'>
         <input type='hidden' name='action' value='$actionUpdateSettings'>
         <p><label>Title:</label><input type=text name='$settingsFieldTitle' size=30 value='" .
            $settingsDb->{$settingsFieldTitle} . "'></p>
         <p><label>Title Font:</label>" . fontOptions($settingsDb->{$settingsFieldTitleFont}) . "</p>
         <p><label>Subtitle:</label><input type=text name='$settingsFieldSubtitle' size=30 value='" .
            $settingsDb->{$settingsFieldSubtitle} . "'></p>
         <p><label>Footer:</label><input type=text name='$settingsFieldFooter' size=30 value='" .
            $settingsDb->{$settingsFieldFooter} . "'></p>
         <p><label>E-mail:</label><input type=text name='$settingsFieldEmail' size=30 value='" .
            $settingsDb->{$settingsFieldEmail} . "'><img src='icon-info.png' title='$emailHelp' alt='Information Icon'></p>
         <p><input class=button type=submit value=' Update Gallery Settings '></p>
         </form>
      </fieldset>\n";
   }

function processUpdateSettings() {
   global $settingsDbFile;
   global $settingsFieldTitle, $settingsFieldTitleFont, $settingsFieldSubtitle, $settingsFieldFooter, $settingsFieldEmail;
   $settingsDb = createEmptyDb();
   $settingsDb->{$settingsFieldTitle} =     $_POST[$settingsFieldTitle];
   $settingsDb->{$settingsFieldTitleFont} = $_POST[$settingsFieldTitleFont];
   $settingsDb->{$settingsFieldSubtitle} =  $_POST[$settingsFieldSubtitle];
   $settingsDb->{$settingsFieldFooter} =    $_POST[$settingsFieldFooter];
   $settingsDb->{$settingsFieldEmail} =     $_POST[$settingsFieldEmail];
   saveDb($settingsDbFile, $settingsDb);
   echo "<div>Updated gallery settings.</div>";
   }

?>
