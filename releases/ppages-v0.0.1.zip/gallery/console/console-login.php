<?php

function displayLoginHtml($createAccount) {
   global $salt;
   if ($createAccount) {
      $msg = "<p class=warning>No user accounts exists yet.&nbsp;
         Create your account by entering a username and password.&nbsp;
         Enter your password a second time for verification</p>";
      $verify = "<p><label>Password:</label><input type='password' id='password2' size='25'></p>";
      $button = "Create Account";
      }
   else
      $button = "Login";
   echo "$msg
   <div class=login>
      <form method='post' action='javascript:login($createAccount);'>
         <p><label>Username:</label><input type='text'     id='username' size='30'></p>
         <p><label>Password:</label><input type='password' id='password' size='25'></p>
         $verify
         <p><label>&nbsp;</label><input type='submit' class='click' value=' $button '></p>
         </form>
      </div>
   <script type='text/javascript'>document.getElementById('username').focus();</script>
   <form action='.' method='post' id='submit-login'>
      <input type='hidden' name='action'   value='login'>
      <input type='hidden' name='username' id='submit-username'>
      <input type='hidden' name='hash'     id='submit-hash'>
      </form>";
   }

function displayLogin() {
   echo "<div class=col1>\n";
   echo "<div class=block2><h3>Login</h3>\n";
   if ($_POST["action"] == "login")
      echo "<p class=warning>Invalid username or password.</p>\n";
   displayloginHtml(getNumAccounts() == 0);
   echo "</div>  <!-- end block2 -->";
   }

?>
