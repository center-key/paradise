<?php

$imageNum = 0;

function getFreeImageId() {
   global $imageDbFilter, $imageNum;
   static $numLen = 3;  //ex: "037"
   if (!$imageNum)  //"gallery/037.json" --> 38
      $imageNum = 1 + trim(end(glob($imageDbFilter)), "a..z/.");
   return str_pad($imageNum, $numLen, "0", STR_PAD_LEFT);  //38 --> "038"
   }

function setNextImageId() {
   global $imageNum;
   $imageNum++;
   }

function generateGalleryDb() {
   global $galleryDbFile, $galleryFolder, $imageDbFilter;
   global $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate, $imageFieldDisplay, $imageFieldTitle, $imageFieldDescription;
   $galleryDb = array();
   $dbFiles = glob($imageDbFilter);
   foreach ($dbFiles as $dbFile) {
      $imageDb = readDb($dbFile);
      if ($imageDb->{$imageFieldDisplay} == "on")
         $galleryDb[$dbFile] = $imageDb;
      }
   saveDb($galleryDbFile, $galleryDb);
   }

function processUpdateImageDb() {
   global $galleryFolder, $imageDbFilter;
   global $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate, $imageFieldDisplay, $imageFieldTitle, $imageFieldDescription;
   $imageId = $_POST[$imageFieldId];
   echo "<div>Updating record: #$imageId</div>";
   $dbFile = $galleryFolder . dbFileName($imageId);
   $imageDb = readDb($dbFile);
   $imageDb->{$imageFieldDisplay} =     $_POST[$imageFieldDisplay];
   $imageDb->{$imageFieldTitle} =       $_POST[$imageFieldTitle];
   $imageDb->{$imageFieldDescription} = $_POST[$imageFieldDescription];
   saveDb($dbFile, $imageDb);
   generateGalleryDb();
   }

function displayPortfolioHtml($id, $status, $title, $desc, $date, $thumbFile, $file, $origFile, $origFileName) {
   global $imageFieldId, $imageFieldDisplay, $imageFieldTitle, $imageFieldDescription;
   global $actionField, $actionUpdateImage;
   $checked = $status ? " checked" : "";
   echo "<a name=$id><div class=image-box><a href='$origFile'
      target='_blank'><img src='$thumbFile' alt='$file'
      title='Click to view original uploaded file ($origFileName)'></a>
      <form method=post action='#$id'>
         <input type='hidden' name='$actionField' value='$actionUpdateImage'>
         <input type='hidden' name='$imageFieldId' value='$id'>
         <label>Display:</label><input type=checkbox name='$imageFieldDisplay'$checked> <small>(show in gallery)</small><br>
         <label>Title:</label><input type=text name='$imageFieldTitle' size=30 value='$title'><br>
         <label>Description:</label><textarea name='$imageFieldDescription' rows=4 cols=25>$desc</textarea><br>
         <label>Uploaded:</label><small>$date</small><br>
         <label>&nbsp;</label><input type=submit value=' Update Image Information '>
         </form>
      <br class=all></div>\n";
   }

function displayPortfolio() {
   global $galleryFolder, $origFileCode, $thumbFileCode, $thumbFileExt, $imageDbFilter;
   global $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate, $imageFieldDisplay, $imageFieldTitle, $imageFieldDescription;
   $dbFiles = glob($imageDbFilter);
   foreach ($dbFiles as $dbFile) {
      $imageDb = ReadDb($dbFile);
      $imageId = $imageDb->{$imageFieldId};
      $base = $galleryFolder . $imageDb->{$imageFieldId};
      $thumbFile = $base . $thumbFileCode . $thumbFileExt;
      $origFileName = $imageDb->{$imageFieldOrigFileName};
      $origFile = $base . $origFileCode . getFileExtension($origFileName);
      displayPortfolioHtml($imageId, $imageDb->{$imageFieldDisplay} == "on",
         $imageDb->{$imageFieldTitle}, $imageDb->{$imageFieldDescription},
         $imageDb->{$imageFieldUploadDate},
         $thumbFile, $file, $origFile, $origFileName);
      }
   if (count($dbFiles) == 0)
      echo "<p>There are no photos in your portfolio.</p>";
   }

?>
