<?php

function createDataFolders() {
   foreach(func_get_args() as $dataFolder)
      if (!is_dir($dataFolder))
         if (mkdir($dataFolder, 0777))  //owner: read/write,  everyone else: read 0644
            echo "<div>Created Folder: $dataFolder</div>\n";
         else
            echo "<div>ERROR: Cannot write to the <b>data</b> folder ($dataFolder).</div>\n";
   }

function createCustomCss() {
   global $customCssFile;
   $customCss =
      "/* PHP Portfolio Art Gallery Exhibit Showcase (PPAGES)   */\n" .
      "/* Edit this CSS file to customize the look of the       */\n" .
      "/* gallery.  Put custom images in the 'graphics' folder. */\n" .
      "/* Find colors at: http://www.centerkey.com/colors       */\n\n" .
      "h1 { font-size: 400%; }\n" .
      "h2 { font-size: 120%; }\n";
   if (!is_file($customCssFile))
      file_put_contents($customCssFile, $customCss);
   }

function startup() {
   global $uploadsFolder, $galleryFolder, $graphicsFolder;
   createDataFolders($uploadsFolder, $galleryFolder, $graphicsFolder);
   createCustomCss();
   }

function displayProcessStatus() {
   global $actionField, $actionUpdateImage, $actionUpdateSettings, $actionChangePassword, $actionCreateAccount;
   startup();
   processUploadsFolder();
   foreach ($_POST as $field=>$value)
      $_POST[$field] = htmlspecialchars($value);  //make safe
   switch ($_POST[$actionField]) {
      case $actionUpdateImage:    processUpdateImageDb();   break;
      case $actionUpdateSettings: processUpdateSettings();  break;
      case $actionChangePassword: processChangePassword();  break;
      case $actionCreateAccount:  processCreateAccount();   break;
      }
   }

?>
