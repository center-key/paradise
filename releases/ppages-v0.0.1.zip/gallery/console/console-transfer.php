<?php

function displayTransfer() {
   ?>
	<div id="file-uploader">		
      <noscript><p>Enable JavaScript to use file uploader.</p></noscript>
      </div>
   <div id="process-files" style="display: none;">Preparing to process files... 
      <img src="loading.gif" alt="Loading Icon"></div>
   <script src="fileuploader.js" type="text/javascript"></script>
   <script type="text/javascript">
      function createUploader() {
         var uploader = new qq.FileUploader({
            element: document.getElementById('file-uploader'),
            action: 'fileuploader.php',
            allowedExtensions: ['jpg', 'jpeg', 'png'],
            onComplete: function(id, fileName, responseJSON) {
               if (id == 0) {  //last image uploaded
                  document.getElementById('process-files').style.display = 'block';
                  setTimeout('window.location.reload();', 3000);
                  }
               },
            });
         //document.getElementsByClassName("qq-upload-button")[0].innerHTML =
         //   document.getElementsByClassName("qq-upload-button")[0].innerHTML.replace(
         //      "Upload a file", "<input type=submit value=' Upload Photos '>");
         }
      window.onload = createUploader;
      </script>
   <?php }

function processUploadsFolder() {
   global $uploadsFolder, $galleryFolder;
   global $origFileCode, $thumbFileCode, $thumbFileExt, $fullFileCode, $fullFileExt;
   global $imageFieldId, $imageFieldOrigFileName, $imageFieldUploadDate, $imageFieldTitle;
   $thumbHeight = 200;
   $fullWidthMax = 1000;
   $fullHeightMax = 600;
   echo "<div>Next record: #" . getFreeImageId() . "</div>\n";
   $files = scandir($uploadsFolder);
   foreach ($files as $file)
      if (isImageFile($file)) {
         //Calculate file names
         $uploadFile = $uploadsFolder . $file;
         $base = $galleryFolder . getFreeImageId();
         $origFile = $base . $origFileCode . getFileExtension($file);
         $dbFile = dbFileName($base);
         echo "<div>Creating Record: #" . getFreeImageId() . " ($file)</div>\n";

         //Move original image
         rename($uploadFile, $origFile);
         list($origWidth, $origHeight, $origType) = getimagesize($origFile);
         $origImage = $origType == 2 ? imagecreatefromjpeg($origFile) : imagecreatefrompng($origFile);
         $aspectRatio = $origWidth / $origHeight;

         //Create thumb image
         $newWidth = $thumbHeight * $aspectRatio;
         $newHeight = $thumbHeight;
         $newFile = $base . $thumbFileCode . $thumbFileExt;
         imageToFile($origImage, $origWidth, $origHeight, $newWidth, $newHeight, $newFile);

         //Create full image
         $scale = min($fullWidthMax / $origWidth, $fullHeightMax / $origHeight, 1);
         $newWidth = $origWidth * $scale;
         $newHeight = $origHeight * $scale;
         $newFile = $base . $fullFileCode . $fullFileExt;
         imageToFile($origImage, $origWidth, $origHeight, $newWidth, $newHeight, $newFile);
         imagedestroy($origImage);

         //Create image database
         $imageDb = createEmptyDb();
         $imageDb->{$imageFieldId} = getFreeImageId();
         $imageDb->{$imageFieldOrigFileName} = $file;
         $imageDb->{$imageFieldUploadDate} = date("Y-m-d");
         saveDb($dbFile, $imageDb);

         setNextImageId();
         }
   }

?>
