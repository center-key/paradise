<?php
$version="0.1";
include "database.php";

$dataFolder = "../data/";
$customCssFile =  $dataFolder . "style.css";  //for site customizations
$graphicsFolder = $dataFolder . "graphics/";  //for site customizations
$uploadsFolder =  $dataFolder . "uploads/";
$galleryFolder =  $dataFolder . "gallery/";
$galleryDbFile =  $dataFolder . dbFileName("gallery");

$origFileCode =  "-original";
$thumbFileCode = "-small";
$thumbFileExt =  ".png";
$fullFileCode =  "-large";
$fullFileExt =   ".jpg";

$imageDbFilter = $galleryFolder . dbFileName("*");

$imageFieldId = "id";
$imageFieldOrigFileName = "original-file-name";
$imageFieldUploadDate = "upload-date";
$imageFieldDisplay = "display";  //boolean: "on"=show, ""=hide
$imageFieldTitle = "title";
$imageFieldDescription = "description";

$actionField =          "action";
$actionUpdateImage =    "update-image";
$actionUpdateSettings = "update-settings";
$actionChangePassword = "change-password";
$actionCreateAccount =  "create-account";

$settingsDbFile = $dataFolder . dbFileName("settings");

include "console.php";
include "console-login.php";
include "console-transfer.php";
include "console-accounts.php";
include "console-settings.php";
include "console-portfolio.php";
include "console-process.php";

function getFileExtension($fileName) {
   return strtolower(strrchr($fileName, "."));
   }

function isImageFile($fileName) {
   return stripos("..jpg.jpeg.png.", getFileExtension($fileName) . ".") > 0;
   }

function imageToFile($origImage, $origWidth, $origHeight, $newWidth, $newHeight, $newFile) {
   $newImage = imagecreatetruecolor($newWidth, $newHeight);
   imagecopyresampled($newImage, $origImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);
   getFileExtension($newfile) == ".png" ?
      imagepng($newImage, $newFile) : imagejpeg($newImage, $newFile);
   imagedestroy($newImage);
   }

?>
