<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<!--  PHP Portfolio Art Gallery Exhibit Showcase (PPAGES)                      -->
<!--  http://www.centerkey.com/ppages                                          -->
<!--                                                                           -->
<!--  GNU General Public License:                                              -->
<!--  This program is free software; you can redistribute it and/or modify it  -->
<!--  under the terms of the GNU General Public License as published by the    -->
<!--  Free Software Foundation; either version 2 of the License, or (at your   -->
<!--  option) any later version.                                               -->
<!--                                                                           -->
<!--  This program is distributed in the hope that it will be useful, but      -->
<!--  WITHOUT ANY WARRANTY; without even the implied warranty of               -->
<!--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                     -->
<!--                                                                           -->
<!--  See the GNU General Public License at http://www.gnu.org for more        -->
<!--  details.                                                                 -->
<!--                                                                           -->
<!--  Copyright (c) individual contributors to the PPAGES project              -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="icon"       href="favicon.png"           type="image/png">
<link rel="stylesheet" href="style.css"             type="text/css">
<link rel="stylesheet" href="data/style.css"        type="text/css">
<link rel="stylesheet" href="slimbox2/slimbox2.css" type="text/css" media="screen">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<script type="text/javascript" src="slimbox2/slimbox2.js"></script>
<?php
   function bbcodeToHtml($bbcode) {
      //Turn text with bbcode into displayable HTML (supports: b, i, url, and entities)
      $code = array('/\[b\](.*?)\[\/b\]/is', '/\[i\](.*?)\[\/i\]/is', '/\[url\=(.*?)\](.*?)\[\/url\]/is', '/\[\&amp\;(.*?)\;\]/is');
      $html = array('<b>$1</b>',             '<i>$1</i>',             '<a href="$1">$2</a>',              '&$1;');
      return preg_replace($code, $html, $bbcode);
      }
   include "console/database.php";
   include "console/console-settings.php";
   $settingsDb = readSettings("data/settings-db.json");
   $title =    bbcodeToHtml($settingsDb->{$settingsFieldTitle});
   $subtitle = bbcodeToHtml($settingsDb->{$settingsFieldSubtitle});

   $f =   "b";
   echo "<!-- f -->\n";
   $footer =   "b";
   echo "<!-- f -->\n";
   $footer =   $settingsFieldFooter;
   echo "<!-- f -->\n";
   $footer =   $settingsDb->{$settingsFieldFooter};
   echo "<!-- f -->\n";
   $footer =   bbcodeToHtml($settingsDb->{$settingsFieldFooter});
   echo "<!-- f -->\n";

   $googleFont = $settingsDb->{$settingsFieldTitleFont};
   echo "<title>$title &bull; $subtitle</title>\n";
   echo "<style>
      @import url('http://fonts.googleapis.com/css?family=" . urlencode($googleFont) . "');
      h1 { font-family: '$googleFont', sans-serif; }
      </style>";
?>
</head>
<body>

<?php

function displayGallery() {
   $fieldId =          "id";
   $fieldTitle =       "title";
   $fieldDescription = "description";
   $titleStyleStart =  "&lt;b&gt;&lt;i&gt;&lt;big&gt;";
   $titleStyleEnd =    "&lt;/big&gt;&lt;/i&gt;&lt;/b&gt";
   $galleryDb = readDb("data/gallery-db.json");
   echo "<div class=gallery>\n";
   foreach ($galleryDb as $imageDb) {
      $id =          $imageDb->{$fieldId};
      $title =       $imageDb->{$fieldTitle};
      $description = $imageDb->{$fieldDescription};
      echo "<div class=image><a href='data/gallery/$id-large.jpg' rel='lightbox{gallery}'
         title='$titleStyleStart$title$titleStyleEnd&lt;br&gt;$description'><img
         src='data/gallery/$id-small.png' title='Click for full size, and right arrow to advance'></a>
         <p>$title</p></div>\n";
      }
   echo "</div>\n";
   }

function displayCreativeCommons() {
   echo "
      <a rel='license' href='http://creativecommons.org/licenses/by-sa/3.0/' target='_blank'><img
      alt='Creative Commons License'
      title='These works are licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License'
      src='http://i.creativecommons.org/l/by-sa/3.0/80x15.png'></a>&nbsp;&nbsp;\n";
   }

function displayFooter($statement) {
   echo "<div class=footer><div>\n";
   if (false) displayCreativeCommons();  //need to add option in settings first
   include "components/bookmarking.html";
   echo "</div>$statement</div>\n";
   }

   echo "<h1>$title</h1>\n";
   echo "<h2>$subtitle</h2>\n";
   echo "<div class=box>\n";
   displayGallery();
   displayFooter($footer);
   echo "</div>\n";
   ?>

<!-- - - - - - - - -->
<!--  Conclusion   -->
<!-- - - - - - - - -->
</body>
</html>
