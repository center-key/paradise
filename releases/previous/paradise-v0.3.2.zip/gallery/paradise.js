//! Paradise PHP Photo Gallery v0.3.2 ~ github.com/center-key/paradise ~ GPLv3
var gallery={start:function a(){$("body >footer .hide-me").remove(),$("form.send-message").attr({method:"post",action:"server/send-message.php"});$(".gallery-images figure").magnificPopup({delegate:">a",type:"image",image:{titleSrc:"data-title"},gallery:{enabled:!0}})}};$(gallery.start);
