<?php
///////////////////////////////////////////////////////////////
// Paradise ~ centerkey.com/paradise                         //
// GPLv3 ~ Copyright (c) individual contributors to Paradise //
///////////////////////////////////////////////////////////////

// Font Options
// List of Google fonts
// See https://fonts.google.com

$googleFonts = array(
   "Allan",
   "Allerta Stencil",
   "Amatic SC",
   "Anonymous Pro",
   "Arimo",
   "Arvo",
   "Bowlby One SC",
   "Bubblegum Sans",
   "Cherry Cream Soda",
   "Chewy",
   "Chango",
   "Coda",
   "Corben",
   "Devonshire",
   "Emilys Candy",
   "Ewert",
   "Galindo",
   "Geo",
   "Geostar",
   "Graduate",
   "Gruppo",
   "Fascinate Inline",
   "Faster One",
   "Flavors",
   "Homemade Apple",
   "Irish Grover",
   "Josefin Sans",
   "Jura",
   "Just Another Hand",
   "Kenia",
   "Kristi",
   "League Script",
   "Life Savers",
   "Lobster",
   "Londrina Outline",
   "Londrina Solid",
   "Love Ya Like A Sister",
   "Monoton",
   "Mouse Memoirs",
   "Neucha",
   "Old Standard TT",
   "Open Sans",
   "Orbitron",
   "Pacifico",
   "Philosopher",
   "Princess Sofia",
   "Reenie Beanie",
   "Rock Salt",
   "Sail",
   "Six Caps",
   "Slackey",
   "Sniglet",
   "Special Elite",
   "Syncopate",
   "Tangerine",
   "UnifrakturMaguntia",
   "Vibur",
   );

?>
