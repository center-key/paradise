<?php
/////////////////////////////////////////////////
// PPAGES ~ centerkey.com/ppages               //
// GPL ~ Copyright (c) individual contributors //
/////////////////////////////////////////////////

$settingsDbFile = "data/settings-db.json";
$galleryDbFile =  "data/gallery-db.json";

function readDb($dbFileName, $isArray) {
   $contents = is_file($dbFileName) ? file_get_contents($dbFileName) : ($isArray ? "[]" : "{}");
   return json_decode($contents);
   }

function getResource() {
   global $settingsDbFile, $galleryDbFile;
   $resource = [
      settings => readDb($settingsDbFile, false),
      gallery => readDb($galleryDbFile, true)
      ];
   return $resource;
   }

function rest() {
   header("Cache-Control: no-cache");
   header("Content-Type:  application/json");
   echo json_encode(getResource());
   }

rest()
?>
