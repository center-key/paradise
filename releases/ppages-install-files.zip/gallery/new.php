<!doctype html>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<!--  PPAGES - PHP Portfolio Art Gallery Exhibit Showcase  -->
<!--  centerkey.com/ppages - Open Source (GPL)             -->
<!--  Copyright (c) individual contributors                -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<html>
<head>
<meta charset=utf-8>
<meta name=apple-mobile-web-app-title content="Gallery">
<link rel=icon             href="http://centerkey.com/ppages/graphics/bookmark.png">
<link rel=apple-touch-icon href="http://centerkey.com/ppages/graphics/mobile-home-screen.png">
<link rel=stylesheet       href="https://cdn.jsdelivr.net/fontawesome/4/css/font-awesome.min.css">
<link rel=stylesheet       href="https://cdn.jsdelivr.net/slimbox/2/css/slimbox2.css">

<link rel=stylesheet       href="https://cdn.jsdelivr.net/dna.js/0/dna.css">

<link rel=stylesheet       href="css/reset.css" >
<link rel=stylesheet       href="css/style.css" >
<link rel=stylesheet       href="data/style.css">
<title>My Gallery!!! &bull; Photography &bull; Art Studio</title>
<style>
      @import url('http://fonts.googleapis.com/css?family=Reenie+Beanie');
      h1 { font-family: 'Reenie Beanie', sans-serif; font-size: 400%; }
      </style>
</head>
<body>

<header>
   <h1>My Gallery!!!</h1>
   <h2>Photography &bull; Art Studio</h2>
</header>
<main>
<ul class=navigation-bar><li class=current><a href='.' class=plain>Gallery</a></li>
<li><a href='?page=contact' class=plain>Contact</a></li>
</ul>
<div class=gallery>
<div class=image><a href='data/portfolio/001-large.jpg' rel='lightbox{gallery}'
         title='&lt;span class=&#039;b i &#039;&gt;Orchid&lt;/span&gt;&lt;br&gt;'><img
         src='data/portfolio/001-small.png' alt='Thumbnail'
         title='Click for full size, and right arrow to advance'></a>
         <p class='b i '>Orchid</p></div>
<div class=image><a href='data/portfolio/002-large.jpg' rel='lightbox{gallery}'
         title='&lt;span class=&#039;b i &#039;&gt;Fog&lt;/span&gt;&lt;br&gt;'><img
         src='data/portfolio/002-small.png' alt='Thumbnail'
         title='Click for full size, and right arrow to advance'></a>
         <p class='b i '>Fog</p></div>
<div class=image><a href='data/portfolio/003-large.jpg' rel='lightbox{gallery}'
         title='&lt;span class=&#039;b i &#039;&gt;&lt;/span&gt;&lt;br&gt;'><img
         src='data/portfolio/003-small.png' alt='Thumbnail'
         title='Click for full size, and right arrow to advance'></a>
         <p class='b i '></p></div>
</div>
</main>
<footer>
<div id=social-buttons class=plain></div>
<div>Copyright &copy; 2015</div>
</footer>

<script src="https://cdn.jsdelivr.net/jquery/2/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/slimbox/2/js/slimbox2.min.js"></script>

<script src="https://cdn.jsdelivr.net/dna.js/0/dna.min.js"></script>

<script src="js/library.js"></script>
<script src="js/app.js"></script>
</body>
</html>
